# MCA Platform — Restructure Report

Workstation-grade redesign of 9 specific areas. No backend logic broken. No features removed. Single new schema migration is **non-destructive** (just adds columns from prior session — already applied).

---

## 1. Files changed

### Pages rewritten (full UI redesigns, same APIs)
| File | What |
|---|---|
| `src/app/(app)/deal-shop/page.tsx` | Workstation-style: top filter bar + sticky tier rail + dense matched table with inline expand |
| `src/app/(app)/active-deals/page.tsx` | Inline-edit table — quick status/rep dropdowns save on change, click row to expand for full edit |
| `src/app/(app)/calculator/page.tsx` | Premium 2-pane layout, true MCA math, interactive sliders for reverse calc, match-quality scoring |
| `src/app/(app)/info/page.tsx` | Card-grid knowledge dashboard — color-coded categories, grouped sections, full-text search |
| `src/app/(app)/funded-board/page.tsx` | Production board — one horizontal row per rep with deal chips and progress bar vs top performer |
| `src/app/(app)/funders/page.tsx` | New `Bulk import` button + modal, `PageHeader`, polished filter chips with counts, search input |

### New API endpoints
| File | What |
|---|---|
| `src/app/api/funder-tiers/reorder/route.ts` | `POST { ids: [tierId, ...] }` — updates `sortOrder` to match the array index |
| `src/app/api/funders/bulk/route.ts` | `POST` accepts CSV upload, returns `{ ok, failed, total, errors[], created[] }`. `GET` returns the CSV template as a downloadable file |

### Settings tab updated
| File | What |
|---|---|
| `src/app/(app)/settings/page.tsx` | `TiersSection` now has up/down arrow buttons (calls `/api/funder-tiers/reorder`), Enter-key submit on add, empty state, toast feedback throughout |

### Backend — unchanged
- `src/lib/calculator/mca.ts` already had correct constants (`businessDaysPerWeek = 5`)
- `src/lib/matching/engine.ts` — untouched
- `src/lib/db/schema.ts` — untouched in this pass
- All other API routes — untouched

**Total: 6 page rewrites, 1 page edit, 2 new API endpoints. ~10 files touched.**

---

## 2. Features improved

### Deal Shop (item 1)
- **Compact top filter bar** — 6 dropdowns + reverse-consolidation toggle in a single row
- **Sticky left tier rail** with per-tier match/exclude counts in colored badges
- **Dense table view** of matched funders (not big cards) — name, submission method, primary email per row
- **Click row to expand inline** — reveals submission emails, phone contacts, restricted states/industries, notes — without leaving the page
- **Excluded funders compacted** into per-tier `<details>` collapsible at the bottom of each section
- **"Submit Deal" button** appears in header actions when matches exist — direct flow

### Active Deals (item 2)
- **No more modal-only editing.** Status and rep are dropdowns directly in the row — change saves immediately with toast confirmation
- **Click row → inline edit form** below the row for everything else (name, merchant info, offer notes)
- **Top filter chips** — All / Shopping / Submitted / Active / Funded / Dead with live counts
- **Search bar** — by deal name, merchant name, or email
- **Inline create form** above the table — no navigation needed
- **Trash icon per row** with confirm + toast feedback

### Funder Tier Management (item 3)
- Already had create / rename / delete — added **reorder** with up/down arrow buttons
- New `/api/funder-tiers/reorder` endpoint validates ownership and persists `sortOrder`
- Empty state when no tiers
- Enter key submits new tier name
- Toast feedback on every action (add, rename, delete, reorder)

### Bulk Funder Upload (item 4)
- **"Bulk import" button** in Funders header opens a modal
- **Step 1: Download template** — one click downloads `funders_template.csv` with all 19 columns + an example row + format notes inline
- **Step 2: Upload** — drag-and-drop or file picker, validates CSV file extension
- **Per-row error reporting** — shows which row failed and why (Zod messages)
- **Auto-creates tiers** that don't already exist
- **Auto-detects duplicate state/industry assignments** via `ON CONFLICT DO NOTHING`
- **Success summary** — green/red/grey tile counts (Imported / Failed / Total)
- **Booleans** accept true/false/yes/no/1/0 for `supports_reverse_consolidation`
- **States** validated as 2-letter codes
- **Up to 3 contacts per funder** (first becomes primary)

### Info Tab (item 5)
- **Card grid** — 1/2/3 columns responsive
- **Color-coded categories** — each unique category name gets a stable color (blue/violet/emerald/amber/rose/cyan/indigo) based on a hash, so "Compliance" is always cyan, "Scripts" always blue, etc.
- **Grouped by category sections** when no filter is active — visual scan
- **Flat grid** when a specific filter or search is active
- **Full-text search** — title and body
- **Click card → side drawer** with category autocomplete from existing values
- **Empty/loading/error states** built-in
- **Hover lift effect** on cards

### MCA Calculator (item 6)
- **True MCA constants** at top of file:
  - `BUSINESS_DAYS_PER_WEEK = 5`
  - `WEEKS_PER_MONTH = 4`
  - `WEEKS_PER_YEAR = 52`
  - `BUSINESS_DAYS_PER_MONTH = 20`
  - `BUSINESS_DAYS_PER_YEAR = 260`
- **Forward calc shows ALL of**:
  - Payment per day or week (top KPI)
  - Total payback (top KPI)
  - Net to merchant (top KPI)
  - Funding amount, origination fee $, total cost of capital
  - Term length displayed in **business days · weeks · months** (all three)
  - Daily / Weekly / Monthly payment equivalents (auto-derived)
  - Commission % and Commission $ (from your commission rules)
- **Frequency toggle** is 2 big buttons labeled "Daily (M–F)" and "Weekly"
- **Footer note** in input panel: "MCA standard: 5 business days/week · 4 weeks/month · 52 weeks/year"
- **Critical bug fix**: weekly term was using `nPay × 7` (calendar days). Now correctly `nPay × 5` (business days)

### Reverse Calculator (item 7)
- **Three interactive sliders**:
  - Factor rate (1.10 – 1.55, step 0.005)
  - Origination fee % (0 – 15%, step 0.5)
  - Term in weeks (4 – 60, step 1)
- **Star markers** on the slider tracks at "clean" MCA values (1.30/1.35/1.40/1.45/1.49 for factor; 3/5/7/10 for fee; 10/12/16/20/24/30/40 for term)
- **"Snap to clean" button** — moves all 3 sliders to nearest clean values
- **Real-time recalc** — predicted funding, payback, payment update on every slider move
- **Match-quality score (0–100)** — combines payment-vs-observed delta + how close each slider is to a clean value. Color-coded green/amber/red
- **Auto-derives term** from observed payment when deposit + payment + factor + fee are all set
- **Match assessment** card shows actionable feedback: "Strong match" / "Try Snap to clean" / "Try a different factor rate"

### Funded Board (item 8)
- **One horizontal row per rep** with:
  - Left summary panel: avatar + initial, name, deal count, total $, progress bar relative to top performer
  - Right deal-chip area: horizontally scrollable, one chip per funded entry showing initials, amount, date, optional note
- **Top 3 reps get medal-style avatars** (gold / silver / bronze rings)
- **Range toggle**: This Week / This Month / All Time chips
- **3 KPI tiles** at top: Volume / Funded Deals / Top Rep — change with the range
- **Inline log form** — drops down above the rows
- **Hover-to-reveal delete** on each deal chip
- **Empty state** with CTA to log first deal

### Cross-cutting (item 9)
- **Reduced clicks**: inline edit on Active Deals, inline expand on Deal Shop, inline create on Funded Board
- **Cleaner layouts**: every page uses the same `PageHeader` primitive with title + description + actions slot
- **Consistent filter chips**: rounded-full pills with count badges, used on Funders / Active Deals / Info / Funded Board
- **Premium feel**: kpi-tile class, hover shadows, primary/10 backgrounds, polished focus rings
- **Better tables**: smaller (h-8) inline form controls inside table cells, sticky headers via card overflow, hover row tint, trash icon on hover
- **Better empty states**: every list view uses `<EmptyState>` primitive with icon + description + action
- **Better feedback**: every save/delete uses toast (no `alert()`)

---

## 3. UX/Layout changes made

| Page | Before | After |
|---|---|---|
| Deal Shop | Big form panels stacked vertically; cards for each match | Top filter bar; sticky tier rail (left); dense table (right); inline expand |
| Active Deals | Click → page → modal to edit | Inline status/rep dropdowns; click row to expand inline edit |
| Calculator | Plain 1-column form | 2/3 split: inputs left, KPIs + detail rows right |
| Reverse Calc | Auto-search loop | Manual sliders + match-quality score + clean-snap |
| Info | Vertical list of rows | Card grid grouped by color-coded category |
| Funded Board | Single big table sorted by date | Horizontal rep rows with deal chips + ranking medals |
| Funders | List of buttons + table | Filter chips with counts + bulk import + search |

---

## 4. Schema / database changes

**None this pass.** All structural data already existed:

- `funder_tiers.sort_order` column already in the schema — the new reorder endpoint just updates it
- `funders` + `funder_contacts` + `funder_tier_assignments` + `funder_restricted_states` + `funder_restricted_industries` — bulk import writes to existing tables
- Branding columns added in prior session (`product_name`, `display_name`, `logo_url`, `primary_color`, `email_signature`) — already in your DB if you upgraded then

---

## 5. What you need to migrate / update

**Nothing manual required** — the setup script handles everything.

### Fresh install
```bash
unzip -o mca-platform.zip && cp -rf mca-platform/. . && rm -rf mca-platform mca-platform.zip
```
Then click Run. The setup script:
- Generates secrets if missing (`ENCRYPTION_KEY`, `NEXTAUTH_SECRET`, `NEXTAUTH_URL`)
- Pushes the schema (no destructive changes)
- Skips re-seeding if `.setup-complete` marker exists

### Upgrading from a previous version
```bash
unzip -o mca-platform.zip && cp -rf mca-platform/. . && rm -rf mca-platform mca-platform.zip
```
Then click Stop → Run. No schema migration required. New endpoints (`/api/funder-tiers/reorder`, `/api/funders/bulk`) become available immediately.

If you want to **wipe and re-seed** for a fresh demo:
```bash
rm .setup-complete
```
Then click Run.

---

## 6. Testing checklist

### Deal Shop
- [ ] Pick Revenue + Position + NSFs → click Find Funders → results appear with tier rail on left, table on right
- [ ] Click a row in the matched table → expands inline showing emails, contacts, restrictions, notes
- [ ] Click a tier in the left rail → only that tier's funders shown
- [ ] Excluded funders show as collapsible "N not qualifying" section under each tier
- [ ] "Submit Deal" button appears in top right when matches exist
- [ ] Tier rail badges show match count (green) and exclude count (grey)

### Active Deals
- [ ] Click status dropdown in a row → status changes immediately, toast appears
- [ ] Click rep dropdown in a row → rep updates immediately, toast appears
- [ ] Click anywhere else on the row → expands inline edit form below
- [ ] Edit a field in the expanded form → click "Save changes" → toast, row collapses
- [ ] Filter chips show counts that match each status
- [ ] Search by deal name, merchant name, or email — narrows results
- [ ] Click "+ New deal" → inline form drops down → fill name → Create → appears in list
- [ ] Trash icon → confirm dialog → row removed + toast

### Funder Tier Management
- [ ] Settings → Funder tiers → up/down arrows reorder tiers
- [ ] Edit tier name → click out → renames + toast
- [ ] Click Delete → confirm → tier removed + funder assignments cleaned up
- [ ] Add new tier → Enter or click Add → toast + appears in list
- [ ] No tiers → empty state message

### Bulk Funder Upload
- [ ] Funders → "Bulk import" → modal opens
- [ ] Click "Download template" → `funders_template.csv` downloads
- [ ] Open template — has all 19 columns + 1 example row + commented format notes
- [ ] Edit example, save, drag CSV into modal → file shown
- [ ] Click "Import" → result tiles appear (Imported/Failed/Total)
- [ ] If all rows succeed → modal auto-closes after 1.5s + toast
- [ ] If some rows fail → error list shows row number + Zod message
- [ ] New funders + auto-created tiers appear in the funder list
- [ ] Existing funders are NOT modified (it's insert-only)
- [ ] Try CSV with invalid `min_credit_tier` → that row reports error

### Info Tab
- [ ] Cards display in grid (1/2/3 col responsive)
- [ ] Each category gets a different color tint badge (stable across reloads)
- [ ] No filter active → entries grouped by category sections
- [ ] Click a category chip → flat grid of just that category
- [ ] Search → matches title or body, hides non-matching cards
- [ ] Click a card → side drawer opens
- [ ] Category field has autocomplete from existing categories
- [ ] Save → toast, card updates in grid
- [ ] Delete from drawer → confirm → card removed + toast
- [ ] Empty state when no entries

### Calculator — Forward
- [ ] Enter Funding $100,000, Factor 1.45, Fee 3%, 100 payments, Daily
- [ ] Top KPIs: payment ≈ $1,450, payback = $145,000, net = $97,000
- [ ] Term row shows "100 business days · 20.0 weeks · 5.00 months"
- [ ] Daily/Weekly/Monthly equivalents computed correctly
- [ ] Commission % matches commission rules table
- [ ] Switch to Weekly + 20 payments → term = "100 business days · 20.0 weeks · 5.00 months" (same!)
- [ ] Per-week payment ≈ $7,250
- [ ] Footer note about 5/4/52 visible

### Calculator — Reverse
- [ ] Enter Deposit $95,000, Payment $710, Daily
- [ ] Sliders snap to current values, term auto-derives
- [ ] Move factor rate slider → predicted payment recalculates instantly
- [ ] Move term slider → predicted payment recalculates
- [ ] "Snap to clean" → all 3 sliders snap to nearest star marker
- [ ] Star markers visible on each slider track at clean values
- [ ] Match quality KPI shows green/amber/red color
- [ ] When match is strong (>75) → "Strong match" green message
- [ ] When match is weak (<50) → "Weak match" red message + suggestion

### Funded Board
- [ ] Each rep has their own horizontal row
- [ ] Left panel: avatar with initial, name, deal count, total $, progress bar
- [ ] Right area: scrollable horizontally with deal chips
- [ ] Top rep has gold ring around avatar; #2 silver; #3 bronze
- [ ] Range toggle (Week / Month / All) updates KPIs and rows
- [ ] KPI tiles show: Volume / Deal count / Top rep — for the selected range
- [ ] "Log funded" button → form drops down → fill → Save → entry appears as new chip in the rep's row
- [ ] Hover a deal chip → trash icon appears in corner
- [ ] Click trash → confirm → chip removed + toast
- [ ] Empty state when nothing in selected range

### General
- [ ] All pages render under `<PageHeader />` with consistent spacing
- [ ] No `alert()` boxes — only toasts
- [ ] Filter chips on Funders / Active Deals / Info / Funded Board look identical (rounded-full, count badge)
- [ ] Search inputs have search icon prefix
- [ ] Side drawers darken page behind, click outside to close
- [ ] Mobile: pages still readable, sidebar collapses to top, table rows wrap appropriately

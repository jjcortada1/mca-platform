# Email Setup with Resend (your own domain)

Reset codes and verification emails now send through **Resend**, from your own domain
(e.g. `noreply@cortadacapitalgroup.com`). Nothing comes from your personal Gmail, and it
works the same for every company you add.

There's also a new **"Send test email" button** in Settings → Security so you can confirm
it's working without guessing.

---

## One-time setup (about 10 minutes)

### Step 1 — Create a Resend account
1. Go to **resend.com** and sign up (free tier = 3,000 emails/month, plenty for resets).

### Step 2 — Add and verify your domain
1. In Resend → **Domains** → **Add Domain**
2. Enter your domain, e.g. `cortadacapitalgroup.com`
3. Resend shows you a few **DNS records** (DKIM, SPF, and usually a return-path). Each is a
   name/type/value row.
4. Go to wherever your domain's DNS is managed (GoDaddy, Namecheap, Cloudflare, etc.),
   and add those records exactly as shown.
5. Back in Resend, click **Verify**. It can take a few minutes (sometimes longer) for DNS to
   propagate. Once all rows show green/verified, you're done.

> Tip: a subdomain like `send.cortadacapitalgroup.com` is common and keeps your main domain's
> email reputation separate. Either works — follow whatever Resend suggests.

### Step 3 — Create an API key
1. In Resend → **API Keys** → **Create API Key**
2. Name it `mca-platform`, give it **Sending access**
3. Copy the key — it starts with `re_...` (you only see it once)

### Step 4 — Add two Secrets in Replit
Open **Secrets** (lock icon) and add:

| Key | Value |
|---|---|
| `RESEND_API_KEY` | the `re_...` key from step 3 |
| `EMAIL_FROM` | `Account Security <noreply@cortadacapitalgroup.com>` |

The address in `EMAIL_FROM` must be at the domain you verified in step 2.

Also confirm this exists so reset *links* work:

| Key | Value |
|---|---|
| `NEXTAUTH_URL` | your real Repl URL, e.g. `https://your-repl.username.repl.co` |

### Step 5 — Restart and test
1. Click **Stop → Run**
2. Go to **Settings → Security → "Send test email to myself"**
3. You should get a toast: "Test email sent via resend to you@…" and the email in your inbox.
4. If it fails, the toast shows the reason (e.g. domain not verified, bad key).

---

## How it behaves

- **Resend is used when** `RESEND_API_KEY` + `EMAIL_FROM` are set (recommended).
- **Falls back to SMTP** if you'd set the old `SYSTEM_SMTP_*` secrets instead.
- **Falls back to console** (dev) if neither is set — and the change-password flow still shows
  the code on screen so you're never locked out.

One sending identity (your domain) covers **all companies** on the platform. None of it is tied
to your personal email.

---

## What changed in the code

| File | Change |
|---|---|
| `src/lib/email/system.ts` | Resend (HTTP API) as primary transport, SMTP fallback, generic "From" |
| `src/app/api/settings/email-test/route.ts` | **New** — test-email endpoint (admin only) |
| `src/app/(app)/settings/page.tsx` | New "Email delivery" card with "Send test email" button |

No database changes. No new npm packages (Resend is called via built-in `fetch`).

---

## Deploying

```bash
unzip -o mca-platform.zip && cp -rf mca-platform/. . && rm -rf mca-platform mca-platform.zip
```
Then add the `RESEND_API_KEY` + `EMAIL_FROM` secrets and click **Stop → Run**.

---

## Testing checklist
- [ ] Resend domain shows "verified"
- [ ] `RESEND_API_KEY` + `EMAIL_FROM` added to Secrets, app restarted
- [ ] Settings → Security → "Send test email" → arrives in inbox, from your domain (not Gmail)
- [ ] Forgot password (logged out) → reset link arrives, from your domain
- [ ] Change password → 6-digit code arrives by email (not shown on screen, since email now works)
- [ ] Add a second company + user → their reset email also comes from your domain, not your personal email

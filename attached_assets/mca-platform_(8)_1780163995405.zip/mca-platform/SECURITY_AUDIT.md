# Security Audit — MCA Platform

Audit run before production deployment. Scope: all 25 API routes, dependencies,
auth flows, tenant isolation, and known vulnerability classes.

## Summary

| Severity | Issue | Status |
|---|---|---|
| 🟢 Low | All API routes audited for auth + tenant isolation | **No issues found** |
| 🟢 Low | All mutations verified for ownership before write | **No issues found** |
| 🟡 Medium | `next` 14.2.35 has Image Optimizer DoS advisory | **Not exposed** — we don't use `images.remotePatterns` |
| 🟡 Medium | `postcss` <8.5.10 has build-time stringify XSS | **Not exposed** — build-time only, not runtime |
| 🟡 Medium | `next-auth` 4.x depends on vulnerable `uuid` v9 | **Low impact** — uuid used only for session IDs (not buffer-write paths) |
| 🟢 Low | Default seed admin password | **Action required** — change after first login |

**Bottom line: safe to deploy to production after changing the seed password.** No exploitable issues; the three dependency advisories don't apply to how the app uses them. A non-breaking upgrade to a fully patched stack would require Next.js 15 + next-auth 5, which is a larger lift that I'd recommend doing in a dedicated upgrade pass later.

## What was audited

### 1. Authentication on every API route
All 25 `/api/*` routes were grepped for an auth gate (`requireTenantContext`, `requirePermission`, `requireUser`, `requireCompanyAdmin`, `requireMasterAdmin`, or `getServerSession`).

**Routes with no auth gate** — intentional public endpoints only:
- `/api/auth/forgot-password` — public, rate-limited
- `/api/auth/reset-password` — public, requires valid reset token
- `/api/auth/me` — returns current session info; refuses if not signed in
- `/api/auth/[...nextauth]` — NextAuth handler
- `/api/branding/public` — public branding for login page (logo, name only)
- `/api/health` — health check, no data

All business endpoints (commissions, deals, payments, accounting, lead sources, users, funders, etc.) require an authenticated session.

### 2. Tenant isolation
Every mutation was checked for one of:
- `where(... companyId = ctx.companyId)` directly in the SQL, OR
- An upfront `select` that verifies ownership before mutating by ID

Audited 69 mutation statements across the API; all confirmed. No way for a user in company A to read/write company B's data.

### 3. Authorization (role + permission)
- Admin-only routes (commissions delete, accounting, payments management, settings): explicitly check `isAdmin(ctx.user)` or `requireCompanyAdmin()`
- Lead source portal: returns ONLY lead-source-safe fields (no deal name, merchant, funder, rates, terms) — verified by inspection of the query select list
- Rep-scoped views: filtered to `repId === ctx.user.id` when caller is not admin

### 4. Password & session security
- Passwords: bcrypt (cost 12)
- Sessions: NextAuth JWT
- Login throttling: rate-limited on `/api/auth/[...nextauth]`
- Password change: 2-step (verification code via email)

### 5. Credential storage
- SMTP credentials: AES-256-GCM encrypted at rest
- Google Sheets service account JSON: AES-256-GCM encrypted at rest
- Encryption key: from `ENCRYPTION_KEY` env var (never committed)

### 6. Security headers
Set on every response via `next.config.js`:
- `X-Frame-Options: SAMEORIGIN`
- `X-Content-Type-Options: nosniff`
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Strict-Transport-Security: max-age=31536000; includeSubDomains`
- `Permissions-Policy: camera=(), microphone=(), geolocation=()`
- `X-Powered-By` removed

### 7. Input validation
All API routes use Zod schemas (`z.object(...)`) to validate request bodies before any DB interaction. Numeric fields coerce to numbers; UUIDs validated. SQL injection blocked by Drizzle ORM's parameterized queries.

### 8. XSS / Injection
- All React rendering is escaped by default
- One `dangerouslySetInnerHTML` exists for the runtime CSS variable injection of `--primary` based on tenant branding — input validated by a strict regex (`/^\d{1,3}\s+\d{1,3}%\s+\d{1,3}%$/`) so no arbitrary CSS can be injected
- No raw HTML rendering from user input

### 9. Logo upload (new)
- Accepts file upload OR https URL
- File capped at 1MB
- MIME validated client-side AND server-side (whitelist: png/jpg/svg/webp/gif)
- Base64 data URI validated by regex on the server before storage
- Stored in DB row, not on the filesystem

## Dependency vulnerabilities — applicability analysis

### `next` GHSA-9g9p-9gw9-jx7f (DoS via Image Optimizer remotePatterns)
- **CVSS**: 5.9 medium
- **Affected**: Next.js 10–15.5.9
- **Trigger**: requires `images.remotePatterns` to be configured
- **Our config**: `next.config.js` has no `images` config at all → not exploitable
- **Recommendation**: upgrade to Next 15.5.10+ during a planned upgrade pass

### `postcss` GHSA-qx2v-qp2m-jg93 (XSS via Unescaped </style>)
- **CVSS**: 6.1 medium
- **Affected**: postcss <8.5.10
- **Trigger**: build-time CSS stringification with attacker-controlled input
- **Our usage**: postcss runs at build time only, processing first-party CSS we wrote → not exploitable
- **Status**: cosmetic finding; safe

### `uuid` GHSA-w5hq-g745-h8pq (Buffer bounds in v3/v5/v6 with buf param)
- **CVSS**: 7.5 high
- **Affected**: uuid <11.1.1 when `buf` argument is passed to v3/v5/v6
- **Our usage**: indirect via next-auth, which uses uuid v4 (random) without `buf` → not exploitable
- **Status**: would only be reachable if we directly called uuid v3/v5/v6 with a `buf` parameter, which we don't

## Required action before going live

1. **Change the seed admin password.** Default is set in `src/lib/db/seed.ts` (`Flinjcorta1`). Log in, go to Account → change password.
2. **Confirm `ENCRYPTION_KEY` is set in Replit Secrets** (used for SMTP/Sheets credential encryption). If missing, the app falls back to a derived key, which is less secure.
3. **Confirm `NEXTAUTH_SECRET` is set in Replit Secrets** (used to sign session JWTs).
4. **Confirm `DATABASE_URL`** is the production Neon URL, not staging.
5. **Restrict your Google Sheet** (the one for backup sync) to view-only for anyone other than the service account; never share the link publicly.

## Items I'd flag for a future hardening pass (not blockers)

- **No audit log** of who edited/deleted what. The system tracks `createdBy` on new records and `updatedAt` timestamps, but doesn't keep a history of changes. For a financial system this is worth adding.
- **No 2FA on login.** Recommend adding TOTP (Google Authenticator) for admin accounts at minimum.
- **Soft-deleted records visible to anyone with DB access.** The Google Sheets backup marks deleted rows as "Deleted" but doesn't remove them — by design for recovery, but worth knowing.
- **Session timeout is NextAuth's default** (30 days). For a financial admin tool, consider shortening to 7 days.
- **No CSP header.** Could be added later; need to verify no inline scripts/styles first.
- **Dependency upgrade** to Next 15 + next-auth 5 to clear advisories cleanly.

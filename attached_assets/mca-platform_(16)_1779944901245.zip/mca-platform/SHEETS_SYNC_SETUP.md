# Google Sheets Live Backup — Setup

Your commission data (rep + lead source) now mirrors to one permanent Google Sheet that updates
automatically. The CRM database stays the source of truth; the Sheet is an independent live backup.

## How it works
- **One permanent sheet, two tabs**: "Rep Commissions" and "Lead Source Commissions" (created automatically).
- **Live sync**: every time a commission is created, edited, status-changed, paid, clawed back, or removed, the sheet updates.
- **Rows matched by ID**: each commission has a unique ID; updates rewrite the matching row — no duplicates.
- **Delete protection**: removing a commission in the CRM does NOT delete its sheet row — it's marked `Record State = Deleted` instead, so the backup stays intact even if CRM data is lost.
- **Sync status**: the settings page shows enabled/disabled, last sync time, and Synced/Failed status. Failed rows retry on the next sync, and you have a manual Force Sync button.

## One-time Google setup (~10–15 min, all clicks)

1. **Google Cloud Console** → console.cloud.google.com → create a project (e.g. "MCA CRM Backup").
2. **Enable the Sheets API**: APIs & Services → Library → search "Google Sheets API" → **Enable**.
3. **Create a service account**: APIs & Services → Credentials → Create Credentials → Service account. Name it, click through (no roles needed), Done.
4. **Create a JSON key**: click the service account → Keys → Add Key → Create new key → **JSON** → it downloads a small `.json` file.
5. **Create your permanent Google Sheet** (or use an existing one). From its URL, copy the **Sheet ID** — the long string between `/d/` and `/edit`:
   `https://docs.google.com/spreadsheets/d/`**`THIS_IS_THE_ID`**`/edit`
6. In the CRM: **Settings → Google Sheets backup** → paste the **Sheet ID** and the **full JSON** from step 4 → **Save settings**.
7. The page now shows the **service account email** (like `...@your-project.iam.gserviceaccount.com`). **Share your Google Sheet with that email as an Editor** (Share button in Google Sheets).
8. Back in the CRM: click **Test connection** (should say "Connected to [sheet name]"), then **Enable sync**, then **Force sync now** to do the first push.

That's it. From then on it keeps that one sheet updated automatically.

## In the CRM (Settings → Google Sheets backup)
- **Sheet ID** + **service account JSON** (JSON is encrypted at rest; leave the JSON box blank later to keep the saved one).
- **Enable / Disable sync** toggle.
- **Test connection** — verifies the service account can reach the sheet.
- **Force sync now** — pushes everything immediately.
- **Status** — last sync time + Synced/Failed, with the error message if something failed.

## What gets synced

**Rep Commissions tab:** Commission ID, Deal ID, Deal Name, Merchant Name/Phone/Email, Rep, Funded Amount, Rate, Term, Fees, Broker Fee, Gross Commission, Rep Split %, Rep Commission, Paid, Pending, Owed, Status, Funding Date, Cleared Date, Early Payoff, Notes, Record State (Active/Deleted), Last Updated.

**Lead Source Commissions tab:** Commission ID, Deal ID, Deal Name, Lead Source, Split %, Flat Amount, Commission, Paid, Owed, Status, Notes, Record State, Last Updated.

## Notes & honest limitations
- **Sync timing**: syncs fire right after each commission change (background). If a sync fails (e.g. Google hiccup, sheet not shared yet), the rows stay marked pending and the next change — or a Force Sync — retries them. There's no separate cron, so for a guaranteed periodic catch-up, click Force Sync, or I can add a scheduled trigger later if you want belt-and-suspenders.
- **Full-tab rewrite**: each sync rewrites both tabs from the database. That's what guarantees rows match by ID with no duplicates and deleted rows show as inactive. For your data volumes this is instant; at tens of thousands of rows we'd switch to incremental writes.
- **Credentials are encrypted** (AES-256-GCM) in your database, same as your SMTP password.

## Database changes (additive, safe)
| Change | Type |
|---|---|
| `sheet_sync_config` table (one row per company) | new |

No existing data touched.

## Deploy
```bash
unzip -o mca-platform.zip && cp -rf mca-platform/. . && rm -rf mca-platform mca-platform.zip && rm -f .setup-complete
```
Then Stop → Run. Then do the Google setup above.

## Testing checklist
- [ ] Settings → Google Sheets backup appears
- [ ] Paste Sheet ID + JSON → Save → service account email shows
- [ ] Share sheet with that email as Editor
- [ ] Test connection → "Connected to [name]"
- [ ] Enable sync → Force sync now → two tabs appear in your sheet with data
- [ ] Add/edit a commission → the sheet row updates (re-open or Force Sync to see)
- [ ] Remove a commission → its row stays, Record State = Deleted

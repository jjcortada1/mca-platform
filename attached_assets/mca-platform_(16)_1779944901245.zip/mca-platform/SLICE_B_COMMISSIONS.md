# Slice B — Commission System (rep + lead source)

This builds the full commission foundation. It's all **additive** — three new tables, new
enum values, new permission keys. No existing table, column, or record is touched.

## What's built

### Rep commissions
- New **Commissions** page (sidebar → Commissions).
- **Admins** see every commission, can edit, and manage payouts. **Reps** see only their own (read-only) with their totals.
- Per-deal commission inputs: gross commission, rep split %, broker fee, funded amount, rate, term, fees, funding date, early-payoff discount, notes.
- **Rep commission math:** split % of gross **plus the same split % of broker fee** (per your spec). Computed automatically.
- **Totals dashboard:** Total / Paid / Pending / Owed / Clawed back.
- **Statuses:** auto-**Pending** for 30 days after funding, then auto-**Cleared**. Admin can manually set Pending / Cleared / Clawed Back. (Manual clawback always sticks; we never auto-override it.)
- **Paid amount tracking** — admin records what's been paid; Owed = commission − paid.

### Lead source commissions (separate from rep)
- New `lead_sources` records (name, contact, optional portal login).
- Per-deal lead source commission: either a **split %** of gross OR a **flat amount**.
- Tracked completely separately from rep commissions.

### Lead source restricted portal
- A `lead_source` login lands on `/lead-source-portal` and is **redirected away from the main app entirely**.
- They see ONLY: amount owed, amount paid, pending, status, and a payment history of amounts + dates.
- They **cannot** see merchant name/phone/email, deal notes, funder info, funded amount, rate, term, fees, or any rep commission detail. The portal API only ever returns their own payout numbers — the private fields are never sent to that role.

### Admin lead source view
- Admins see full lead source detail (deal, merchant, funded amount, gross, broker fee, rep split, lead source split/flat, owed, paid, balance, status, notes) via the lead-source-commissions API.

### Soft-delete everywhere
- Deleting a commission sets `isDeleted = true` rather than removing the row — so the upcoming Google Sheet backup can mark it inactive instead of losing it. Nothing is hard-deleted.
- Every commission row also carries `syncState` (pending/synced/failed) and sync bookkeeping fields, **ready for the Google Sheets sync in the next step**.

## Database changes (all additive)
| Change | Type |
|---|---|
| `lead_sources` table | new |
| `deal_commissions` table | new |
| `lead_source_commissions` table | new |
| `user_role` enum gains `lead_source` | add-value (safe) |
| `commission_status`, `sync_state` enums | new types |
| permission keys `commissions.view`, `commissions.manage` | new |

No drops, no renames, no reseed. `drizzle-kit push` adds only the above.

## Deploy
```bash
unzip -o mca-platform.zip && cp -rf mca-platform/. . && rm -rf mca-platform mca-platform.zip && rm -f .setup-complete
```
Then **Stop → Run** (the `.setup-complete` removal lets the additive schema push create the new tables). Your data is preserved.

---

# Next: Google Sheets live backup — what the setup involves

You asked me to explain the Google Cloud part before committing. Here it is in plain terms.

## Why it's needed
To let the CRM **write to your Google Sheet automatically and forever** (no manual exports, one permanent sheet), Google requires the app to authenticate as a "service account" — a robot Google account that belongs to your project. This is the standard, secure way; it's how every app that writes to Sheets works.

## The one-time setup (about 10–15 minutes, all clicks, no coding)
1. **Google Cloud Console** (console.cloud.google.com) → create a project (e.g. "MCA CRM").
2. **Enable the Google Sheets API** for that project (APIs & Services → Library → search "Google Sheets API" → Enable).
3. **Create a service account** (APIs & Services → Credentials → Create Credentials → Service Account). Give it a name; no special roles needed.
4. **Create a key** for that service account → choose **JSON** → it downloads a small `.json` file. This file is the credential the CRM uses.
5. **Create your permanent Google Sheet** (or pick an existing one). Note its **Sheet ID** (the long string in the URL between `/d/` and `/edit`).
6. **Share the Sheet** with the service account's email (it looks like `something@your-project.iam.gserviceaccount.com`) as an **Editor**. This is what lets the robot write to it.
7. In the CRM admin settings (which I'll build next), paste the **JSON credentials** and the **Sheet ID**, then click **Test connection**.

After that, the CRM writes commission data into two tabs ("Rep Commissions" and "Lead Source Commissions") on that one sheet, updating the same rows forever, with retry-on-failure and a visible sync status.

## What I'll build on the app side (next slice)
- Admin settings: paste Google credentials (encrypted at rest) + Sheet ID, enable/disable sync, **Test connection**, **Force sync** buttons.
- Live sync on every commission create/update/status/paid/clawback/delete.
- Two tabs, unique row IDs, update-in-place (no duplicate rows).
- Soft-deleted records marked "Deleted/Inactive" in the sheet, never removed.
- Retry queue + sync status (Synced / Pending / Failed) shown in the UI.

## The decision for you
The only thing you need to confirm is whether you're comfortable doing steps 1–6 above (creating the Google Cloud project + service account + sharing the sheet). It's all point-and-click in Google's console — I'll give you exact screenshots-level instructions when we wire it. If that's fine, say "continue" and I'll build the Sheets integration on top of this commission foundation.

## Testing checklist (Slice B)
- [ ] Commissions appears in the sidebar
- [ ] Admin: create a commission for a deal (gross + split % + broker fee) → rep amount computes correctly
- [ ] Admin: set paid amount + status → totals update; Owed = commission − paid
- [ ] A commission older than 30 days (by funding date) shows as Cleared automatically
- [ ] Rep login: sees only their own commissions, no edit controls
- [ ] Create a lead source + a lead source login → that login lands on the restricted portal, sees only payout totals, NO merchant/deal data
- [ ] Remove a commission → it disappears from the list but is soft-deleted (kept for backup)
- [ ] All existing data intact after deploy

# MCA Platform — Restructure Report

Refines settings, intake, active deals, tier system, upload template, and number formatting. **Backend logic preserved**: all matching, calculator math, email sending, and existing API routes still work. New layer adds editable options and admin controls.

---

## 1. Files changed

### New files
| File | What |
|---|---|
| `src/components/ui/money-input.tsx` | `MoneyInput` primitive — comma display, clean numeric storage |
| `src/app/api/settings/match-options/route.ts` | GET (list options) + PUT (admin replace) for editable dropdowns |

### Modified — backend / schema
| File | What |
|---|---|
| `src/lib/db/schema.ts` | New `match_options` table (companyId, kind, value, label, sortOrder, meta JSON) |
| `src/lib/db/seed.ts` | New `DEFAULT_MATCH_OPTIONS` seed + `ensureMatchOptions()` idempotent backfill on every setup |
| `src/lib/matching/engine.ts` | Score-based credit comparison via `creditScoreValue`. Backward compatible — legacy enum still works. Renamed `matchAllFunders` → `matchAll`. |
| `src/lib/validation/schemas.ts` | `dealShopMatchSchema` accepts both `creditScore` (legacy) and `creditScoreValue` (new) |
| `src/app/api/deal-shop/match/route.ts` | Updated import + call site for renamed `matchAll` |
| `src/app/api/funders/bulk/route.ts` | Simplified template + new column aliases (submission_email, contact_name/phone/email, additional_rules) — **legacy contact_name_1/2/3 still supported** |

### Modified — pages
| File | What |
|---|---|
| `src/app/(app)/deal-shop/page.tsx` | Centered card-style intake (max-w-3xl), 2-col grid, loads dropdowns from `/api/settings/match-options`, has both "range" and "exact monthly revenue" via MoneyInput |
| `src/app/(app)/active-deals/page.tsx` | Wider table — visible columns now: Deal · First · Last · Phone · Email · Offer/Notes · Status · Rep · Updated. Inline status/rep dropdowns still save on change. Click row to expand inline edit form. |
| `src/app/(app)/settings/page.tsx` | New `'Matching'` tab group containing existing `Funder tiers` + new `Match options` tab. `MatchOptionsSection` lets admin edit credit ranges, revenue ranges, industries, deal types, position options. |
| `src/app/(app)/funders/page.tsx` | Min revenue field uses `MoneyInput`. Bulk-import modal "Format requirements" rewritten — Required (8) / Optional (7) sections. |
| `src/app/(app)/funded-board/page.tsx` | Amount funded field uses `MoneyInput` |
| `src/app/(app)/calculator/page.tsx` | Funding amount, deposit, payment fields all use `MoneyInput` |
| `src/app/(master)/master/funders/page.tsx` | Min revenue field uses `MoneyInput` |
| `src/components/ui/primitives.tsx` | Re-exports `MoneyInput` and `parseMoneyString` |

**Total: 2 new files, ~13 modifications.**

---

## 2. Features updated

### 1. Bulk Funder Upload — simplified template
- **Required (8 cols)**: name, tiers, submission_method, submission_email, contact_name, contact_phone, contact_email, notes
- **Optional advanced (7 cols)**: min_revenue, min_credit_tier, max_positions, restricted_states, restricted_industries, supports_reverse_consolidation, additional_rules
- Two sample rows in template: minimal (only required) + full (with restrictions)
- Inline `# Notes:` block at bottom of CSV documents every column
- Empty optional fields = no restriction
- Tiers that don't exist are auto-created
- Per-row error reporting with Zod messages
- Old multi-contact format (`contact_name_1`, `contact_name_2`, etc.) **still accepted** for backward compatibility

### 2. Editable Matching Options (Settings → Match options)
New admin tab lets you edit:
- **Credit ranges** — value, label, `minScore` floor (used by matching engine)
- **Revenue ranges** — value, label, `minRevenue` / `maxRevenue` bounds
- **Industries** — value, label (free text)
- **Deal types** — value, label (keep `standard_mca` / `reverse_consolidation` as values to preserve matching engine compatibility)
- **Position options** — value, label

Per option you can:
- Edit value (internal) and label (shown to users)
- Set meta fields (minScore for credit; minRevenue/maxRevenue for revenue)
- Reorder with up/down arrows
- Delete
- Add new

Saves all options for a kind at once via `PUT /api/settings/match-options` — atomic replace.

Default seeded options match JJ's spec exactly:
- **Credit**: Unknown · Above 700 · 650 – 699 · 600 – 649 · Below 600
- **Revenue**: Below $25K · $25K – $99K · $100K+
- **Industries**: 15 common MCA industries + Other
- **Deal types**: Standard MCA · Reverse Consolidation

### 3. Deal Shopping Intake Form
- **Centered** `max-w-3xl` card layout with header icon and "Deal Profile" title
- **Clean 2-col grid** of related fields
- All dropdowns dynamically loaded from `/api/settings/match-options`
- Both **revenue range dropdown** and **exact monthly revenue** fields — exact wins if entered
- Industry dropdown includes "Other" option that bypasses filtering (matches engine behavior)
- Deal type rendered as 2 large buttons (Standard MCA / Reverse Consolidation)
- Validation summary appears inline if required fields missing
- Results render in dedicated section below with sticky tier rail + dense matched table

### 4. Editable Industries
- Editable from Settings → Match options → Industries
- Add / rename / remove / reorder
- "Other" must be present (bypasses industry filter — matches engine)
- Industry list also feeds the Funders edit page when picking restricted industries
- (Note: existing funders' restricted_industries entries are stored as free text in `funder_restricted_industries`, so they continue to work even if you remove an industry from the dropdown)

### 5. Active Deals Table
Visible inline columns now (no clicking required):
- Deal · First name · Last name · Phone · Email · Offer/Notes (line-clamped to 2 lines) · Status (inline dropdown) · Rep (inline dropdown) · Updated · Delete

Status and rep dropdowns save **immediately** on change with toast feedback. Other fields editable by clicking row to expand inline edit form below.

Table has horizontal scroll on narrow viewports (min-width 1100px). Phone is `tabular-nums whitespace-nowrap`. Email uses `font-mono truncate max-w-[200px]` with full email shown in tooltip.

### 6. Funder Tier Management
Already had create / rename / delete from prior session. **Now in Settings → Matching → Funder tiers** alongside Match options. Includes up/down reorder.

Multi-tier assignment per funder is supported via `funder_tier_assignments` join table — the funder edit drawer already lets you tick multiple tier checkboxes.

### 7. Number Formatting Everywhere
New `<MoneyInput>` primitive:
- Type-as-you-go displays commas: `50000` → `50,000`
- Stores clean numeric value (number, not string)
- `$` prefix shown inline
- Right-aligned `tabular-nums`
- Doesn't reformat while focused (no cursor jumps)
- Reformats on blur
- Optional `decimals={2}` mode for cents

Applied to:
- Deal Shop — exact monthly revenue
- Funders — min monthly revenue
- Funded Board — amount funded
- Calculator — funding amount, deposit, payment
- Master Funders — min revenue

(The display side of money in tables/cards already uses `formatCurrency()` from `@/lib/utils` which already shows commas — only the input fields needed the upgrade.)

### 8. System Flexibility
Admin now controls (without code changes):
- Credit ranges (label + score floor)
- Revenue ranges (label + min/max)
- Industries
- Deal types (labels)
- Positions (labels)
- NSFs (seeded but no admin UI in this pass — they'd live alongside the others)
- Funder tiers (already had admin UI)
- Commission rules (already had admin UI)
- Structured email fields (already had admin UI)

---

## 3. Schema / database changes

### One new table: `match_options`
```sql
CREATE TABLE match_options (
  id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  company_id    UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
  kind          VARCHAR(30) NOT NULL,        -- 'credit_range' | 'revenue_range' | 'industry' | ...
  value         VARCHAR(100) NOT NULL,       -- internal id (e.g. 'above_700')
  label         VARCHAR(200) NOT NULL,       -- display label (e.g. 'Above 700')
  sort_order    INTEGER NOT NULL DEFAULT 0,
  is_active     BOOLEAN NOT NULL DEFAULT true,
  meta          JSONB                        -- { minScore?, minRevenue?, maxRevenue?, ... }
);
CREATE INDEX match_options_company_kind_idx ON match_options (company_id, kind);
CREATE UNIQUE INDEX match_options_company_kind_value_idx ON match_options (company_id, kind, value);
```

### NO destructive changes
- `credit_tier` enum unchanged
- All existing tables untouched
- `funders.min_credit_tier` still uses the legacy enum (`unknown` / `under_550` / `550_599` / `600_649` / `650_plus`)
- Deal shop sends a numeric score floor (`creditScoreValue`) which the engine maps against the funder's enum via `TIER_TO_FLOOR`. Both old and new code paths work.

---

## 4. What you need to migrate / update

**Nothing manual.** The setup script handles everything.

### Upgrade path (preserves your data)
```bash
unzip -o mca-platform.zip && cp -rf mca-platform/. . && rm -rf mca-platform mca-platform.zip && rm .setup-complete
```
Then click **Stop → Run** in Replit. The setup script:
1. Detects new schema (`match_options` table) and pushes it via `drizzle-kit push --force`
2. Runs `ensureMatchOptions()` for your existing company — adds the new defaults idempotently (won't touch any options you've already customized)
3. Skips re-seeding companies/users/funders (those exist already)
4. Boots dev server

### Fresh install
Same command above. Setup script generates secrets, creates company, creates admin user, seeds default match options.

### Verified migration
Tested on a fresh Postgres database — schema applied cleanly, all 6 kinds of match options seeded:
```
 credit_range    | 5
 revenue_range   | 3
 industry        | 15
 deal_type       | 2
 position_option | 6
 nsf_option      | 6
```

### Production build
`npx next build` — clean, all 17 routes compile, TypeScript 0 errors.

---

## 5. Testing checklist

### Match options admin
- [ ] Settings → Matching → Match options → click "Credit ranges" chip
- [ ] See 5 options: Unknown, Above 700, 650 – 699, 600 – 649, Below 600
- [ ] Click a label, edit it, click Save changes → toast appears
- [ ] Click Add option → fill value + label + minScore → Save → appears
- [ ] Click up/down arrows on an option → reorders
- [ ] Click Delete → row disappears (only persists on Save)
- [ ] Switch to "Revenue ranges" chip → minRevenue and maxRevenue meta fields appear
- [ ] Switch to "Industries" → no meta fields, just value+label
- [ ] Reload page → changes persisted

### Deal Shop intake
- [ ] Form is centered, not stretched across the page
- [ ] Revenue dropdown shows: Below $25K / $25K – $99K / $100K+ (or whatever you customized)
- [ ] Exact monthly revenue field shows commas as you type (50000 → 50,000)
- [ ] Credit dropdown shows: Unknown / Above 700 / 650 – 699 / 600 – 649 / Below 600
- [ ] Industry dropdown shows your edited industries
- [ ] Pick "Other" for industry → industry filter is bypassed in matching
- [ ] Pick "Other" for state → state filter is bypassed
- [ ] Click Find Funders without revenue or position selected → red error toast
- [ ] With valid inputs → results section appears below
- [ ] Submit Deal button appears in header when matches exist

### Active Deals
- [ ] Table shows visible columns: Deal · First · Last · Phone · Email · Offer/Notes · Status · Rep · Updated
- [ ] Phone number renders with monospace digits
- [ ] Email truncates with "…" when long, hover shows full
- [ ] Offer/Notes shows up to 2 lines of the offerNotes field
- [ ] Status dropdown changes color (success/warning/etc.) per status
- [ ] Click status dropdown → change → saves immediately + toast
- [ ] Click rep dropdown → change → saves immediately + toast
- [ ] Click row body → expands inline edit form below row
- [ ] Edit deal name in form → click Save changes → toast + row updates
- [ ] Click trash → confirm → row removed
- [ ] Filter chips work + show counts
- [ ] Search by name / merchant / email narrows results

### Funder tiers (Settings → Matching → Funder tiers)
- [ ] Create tier (type name, click Add) → toast + appears in list
- [ ] Up/down arrows reorder
- [ ] Edit name in input → click out → renames
- [ ] Delete → confirm → removed
- [ ] Tier appears in deal shop tier rail when funders are assigned to it

### Bulk Funder Upload
- [ ] Funders → Bulk import → modal opens
- [ ] Click Download template → CSV has 15 columns (8 required + 7 optional)
- [ ] Open CSV — first sample row uses only required, second has full restrictions
- [ ] Edit minimal sample → upload → result tile shows "1 imported"
- [ ] New funder appears in funder list with primary contact set
- [ ] Try CSV with bad credit tier value → row reports validation error
- [ ] Try CSV with new tier name → tier auto-created
- [ ] Old CSV with `contact_name_1`/`_2`/`_3` columns also imports correctly

### Number formatting
- [ ] Calculator → type 100000 in Funding → shows 100,000
- [ ] Tab away → reformatted with commas
- [ ] Click back in field → can edit normally without losing position
- [ ] Calculator results all show commas (already worked via formatCurrency)
- [ ] Funded Board → log entry → amount field shows commas
- [ ] Funders → edit funder → min revenue shows commas
- [ ] Deal Shop → exact monthly revenue shows commas
- [ ] All commas display visually; database stores clean number (verify by checking `funded_entries.amount_funded` directly — should be numeric like 50000.00)

### Reverse Calculator (item 9 — should still work)
- [ ] Tab to reverse calc
- [ ] Sliders work for factor rate, fee %, term weeks
- [ ] Snap to clean works
- [ ] MCA constants 5/4/52 still respected (5 business days/week, 4 weeks/month, 52 weeks/year)
- [ ] Match quality score updates as you adjust

### Existing functionality (regression check)
- [ ] Login still works
- [ ] Submit deal → emails still send
- [ ] Funded board production rows still render
- [ ] Info knowledge base still grouped by category with color-coded chips
- [ ] Funder tier reorder still works
- [ ] Settings other tabs (Branding, Email mode, SMTP, Commission, Email fields, Users) still load

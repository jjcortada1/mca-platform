# Update — Slice A (Deal Shop, Submissions, Active Deals, Funders, Funded Board, Calculator)

This is the first of three slices implementing your full request list. Everything here is
**additive and non-destructive** — no existing data, records, users, or relationships are
touched. New database columns are nullable; new status values are added alongside the old
ones (legacy values kept so existing deals still work).

## What's in this slice

### Deal Shop
- **Revenue dropdown is now range-only**: Under $25K / $25K to $100K / $100K+. The free-text "exact amount" field was removed.
- **Credit order reversed** low→high (Below 600 → 600 to 650 → 650 to 700 → Above 700 → Unknown). *(Seed default — see "Existing data note" below.)*
- Number of positions: unchanged, as requested.

### Submissions
- **Manually add a submission** (+ Add manual button): record a deal you already sent, picking a funder from the directory OR typing a funder name. No email is sent.
- **Delete a submission** (✕ on each row): removes the submission and its funder rows. The underlying deal is NOT deleted.

### Active Deals
- **Offer amount field** added to the deal edit panel (accepts decimals).
- **Status options updated** to: Submitted, Active, Not Active, Offer, Funded, Declined.
- Legacy statuses ("shopping", "dead") are **kept in the database** so old deals aren't broken — they display as "Submitted (legacy)" / "Declined (legacy)" until you change them. New deals default to "Submitted".

### Funders
- **Quick View** (eye icon on each row): a popover showing contacts (click-to-email / click-to-call), min revenue, max positions, min credit, tiers, restrictions, and notes — without opening the full editor. "Edit full details" button jumps to the editor.
- Existing funder data untouched.

### Funded Board
- **"Funded With" free-text field**: type any funder name when logging a funded deal. Deliberately NOT tied to the funder directory dropdown, so reps can type anything. Shows on each deal card as "via [name]".

### Calculator
- **"Reverse Calculator" renamed to "Merchant Funding Estimator"** for clarity.
- **Decimal support** ($12,345.67) in funding amount, deposit, and payment fields.
- **Snap to Clean is now multi-suggestion**: instead of forcing one result, it generates several clean MCA structures, scores each by how closely it reproduces the observed payment (match quality %), and lets you tap between them. The best is applied automatically; you can pick any other.

### Settings — Industries & States (already present, confirmed)
- Settings → Match options has **Industries** and **States** editors (add / edit / remove / reorder).
- Deal Shop pulls both dropdowns from these dynamically.
- States: only your configured states show, plus "Other" (which bypasses state filtering). Leave States empty to show all 50.
- Funder-level allowed/restricted industries and restricted states already exist on each funder and feed the matching engine.

## Database changes (all additive — safe for live data)
| Change | Type | Safe? |
|---|---|---|
| `deals.offer_amount` (numeric, nullable) | new column | ✅ nullable, legacy rows = NULL |
| `funded_entries.funded_with` (varchar, nullable) | new column | ✅ nullable, legacy rows = NULL |
| `deal_status` enum gains `not_active`, `offer`, `declined` | enum add-value | ✅ `ALTER TYPE ADD VALUE`, never touches rows |
| `verification_codes` table (from password feature) | new table | ✅ additive |

No columns renamed or dropped. No data reseeded. `drizzle-kit push` applies only these additions.

## Existing data note (revenue + credit labels)
The seed file now uses your exact labels/order, but **the seed only affects fresh installs**. Your live database already has the older revenue labels and credit order. To update them on your live data, go to **Settings → Match options → Revenue ranges / Credit ranges** and edit/reorder there (the editor supports this). Nothing breaks if you don't — the dropdowns just show the older labels until you update them.

## Deploying
```bash
unzip -o mca-platform.zip && cp -rf mca-platform/. . && rm -rf mca-platform mca-platform.zip && rm -f .setup-complete
```
Then **Stop → Run**. Deleting `.setup-complete` lets the additive schema push run (creates the new columns + enum values). Your data is preserved.

## Still to come (next slices)
- **Slice B:** Commission portal, backend deal→rep assignment, per-deal commission inputs (gross / split % / broker fee), commission statuses (auto-pending 30 days → cleared, manual clawback), commission tracking totals. Needs a new `deal_commissions` table (additive).
- **Slice C:** Renewal/payoff estimator (payoff date from funding date, 4wk/mo, 5 days/wk, daily vs weekly, ~45% paid-in renewal point).

## Testing checklist
- [ ] Deal Shop: revenue dropdown shows only the 3 ranges, no exact field; Find Funders works
- [ ] Submissions: + Add manual creates a record; ✕ deletes one
- [ ] Active Deals: status dropdown shows the 6 new options; existing deals still show (legacy); offer amount saves
- [ ] Funders: eye icon opens quick view with contacts; existing funders intact
- [ ] Funded Board: "Funded with" field saves and shows on the card
- [ ] Calculator: tab reads "Merchant Funding Estimator"; decimals work; "Suggest clean structures" shows multiple options with % quality
- [ ] All existing data (deals, funders, submissions, users) still present after deploy

# Fixes — Add User, Change Password, Forgot Password, Funder Upload

This round fixes the four things you reported. Each had a real root cause, not just a setup issue.

---

## 1. "It doesn't let me add a user" — FIXED

**Root causes (two):**
- The new-user password silently required **10 characters**, but nothing in the form told you that. Typing a shorter one gave a vague "Save failed."
- Editing an existing user was **structurally broken**: the form sent the whole user (name, email, role, permissions, password) to an endpoint that only accepted a password field and required 10 chars — so edits, and password-on-edit, never worked.

**What I changed:**
- Standardized the password minimum to **8 characters** everywhere (create user, edit user, change password — they were inconsistent before).
- Added **clear client-side validation** to the user form: it now tells you exactly what's wrong ("Name must be at least 2 characters", "Enter a valid email", "Password must be at least 8 characters") before sending.
- Rewrote the edit-user endpoint (`PUT /api/users/[id]`) to accept a **full update** — name, email, role, active status, permissions, and an **optional** password (blank = keep current). Editing users now works completely.
- Added a password hint under the field: "At least 8 characters."
- Improved server error messages so a validation failure shows the actual reason instead of "Validation failed."

---

## 2. "It doesn't let me change my password" — FIXED

**Root cause:** The change-password flow emails a 6-digit code. If system email (`SYSTEM_SMTP_*`) isn't configured, the code went to the **server console** — which you'd never see — leaving the flow as a dead end.

**What I changed:**
- When email isn't configured, the code is now **shown directly on screen** to you (you're already logged in and changing your *own* password, so it's safe). A clear amber box displays the 6-digit code so you can complete the change immediately — no SMTP required.
- When email *is* configured, it sends the code to your inbox as before and does **not** show it on screen.
- So: change password works **with or without** email set up.

---

## 3. "Forgot password on the pre-login screen doesn't work" — FIXED (with a caveat)

**Root cause:** Same email dependency. Forgot-password emails a reset link, but with no `SYSTEM_SMTP_*` configured, nothing sends — and the page just said "check your inbox," so it looked broken.

**What I changed:**
- The forgot-password success screen now explains clearly: if you didn't get the email, email delivery must be configured by an admin, and **an admin can change passwords from Settings → Security** in the meantime.

**The caveat (important):** A *logged-out* user genuinely can't be shown a reset code on screen — that would let anyone reset anyone's password. So **forgot-password from the login screen requires `SYSTEM_SMTP_*` to be configured** to actually email the link. Until you set that up:
- **You (admin)** change your password via **Settings → Security** (works without email now — shows the code on screen).
- **A rep who's locked out** → you reset their password for them in **Settings → Users** (edit the user, set a new password).

Once you configure `SYSTEM_SMTP_*` (one system email account, see below), the self-service forgot-password link works for everyone.

---

## 4. Funder upload was messy — REDESIGNED

**What I changed:** The "Add funders" dialog now has **two clean modes**:

**"Type them in" (new, default):** A clean table with a clear **header line** (Name, Tier(s), Submission email, Contact name, Contact phone, Min revenue, Notes) and **simple input boxes** under each — exactly what you asked for. Starts with 3 blank rows, "Add another row" for more, trash icon to remove. Only **Name** is required; leave the rest blank if unknown. Click "Save funders" and they're all added at once.

**"Upload CSV" (kept):** The download-template + upload flow, for big batches.

No CSV knowledge needed for everyday use — just type names into the grid.

---

## To configure system email (enables emailed codes + forgot-password links)

One account, set once in Replit Secrets. Use a neutral address so it's generic:

| Key | Value |
|---|---|
| `SYSTEM_SMTP_HOST` | `smtp.gmail.com` |
| `SYSTEM_SMTP_PORT` | `587` |
| `SYSTEM_SMTP_USER` | a dedicated address, e.g. `youralerts.noreply@gmail.com` |
| `SYSTEM_SMTP_PASS` | Gmail App Password for that account |
| `NEXTAUTH_URL` | your real Repl URL (so reset links work) |

Reps never touch this — it only sends security emails to their normal inboxes.

---

## Deploying

```bash
unzip -o mca-platform.zip && cp -rf mca-platform/. . && rm -rf mca-platform mca-platform.zip
```
Then **Stop → Run**. No new tables this round, so your data is untouched. (Deleting `.setup-complete` is optional and harmless.)

---

## Testing checklist

### Add user
- [ ] Settings → Users → + Add user → fill name, email, password (8+ chars), role → Save → "User created"
- [ ] Try a 5-char password → clear message "Password must be at least 8 characters" (no more vague fail)
- [ ] Click an existing user → change their name → Save → updates
- [ ] Click an existing user → set a new password (8+) → Save → that user can log in with it
- [ ] Leave password blank when editing → other changes save, password unchanged

### Change password (works even without email configured)
- [ ] Settings → Security → enter current + new (8+) → Send code
- [ ] If email NOT set up: a 6-digit code appears on screen in an amber box → enter it → "Password changed"
- [ ] If email IS set up: code arrives in your inbox instead → enter it → changed
- [ ] Log out, log in with the new password → works

### Forgot password
- [ ] With `SYSTEM_SMTP_*` set: login → Forgot password → enter email → reset link arrives → reset works
- [ ] Without it: success screen explains an admin can change it in Settings → Security

### Funder upload
- [ ] Funders → Bulk import → "Type them in" tab → clean table with header line + input rows
- [ ] Type a name in row 1 → Save funders → appears in funder list
- [ ] Add another row → fill two funders → Save → both added
- [ ] "Upload CSV" tab still downloads template + imports a file

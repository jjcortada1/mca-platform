# Platform restructure — items 1–7 (all in this build)

Built straight through, one after the next. All additive schema — no data dropped.

## 1. Commission payment logging
- New `commission_payments` table: amount, date, method (ACH/wire/check/cash/Zelle/other), confirmation #, notes.
- In the Commissions page, expand any commission → **+ Log a payment** (amount, method, confirmation #, date). Logging against a commission also bumps its paid amount automatically.
- API: `GET/POST /api/commission-payments` (admin logs; reps see their own).

## 2. Draws / advances
- New `commission_draws` table: amount, date, recouped amount, notes.
- API: `GET/POST /api/commission-draws`. Draws outstanding surface on the dashboard + per-rep sections.

## 3. Master overview dashboard
- New `/api/portfolio` aggregates company-wide: funded volume, active deals, eligible renewals, defaults/collections, total/paid/pending commissions, draws outstanding, and deal counts by status.
- Dashboard now **leads with the portfolio overview + deal-status pipeline**, with commissions moved lower (item from the spec).

## 4. Per-rep dashboard sections
- Admin dashboard lists each rep; click to expand their funded volume, active/renewal/default/paid-off counts, commission, paid, pending, and draws outstanding.

## 5. Funder bulk-upload overhaul
- Funder model extended: multiple **emails** + **phones** (JSON arrays), and a **role** on contacts.
- CSV import now supports: `emails`, `phones` (pipe/comma separated), named-role contacts (`iso_rep`, `iso_rep_email`, `iso_rep_phone`, and the same for `underwriter` and `funding_manager`), plus existing tiers, restricted states/industries.
- **Duplicate detection**: rows whose funder name already exists are skipped and reported, not duplicated.

## 6. Deal timeline
- Every funded deal's expanded view shows a **timeline strip**: Funded → Renewal (50%) → Payoff, with a live "Today" marker and the paydown progress overlaid.

## 7. Commissions lower + font
- Commissions section moved beneath the portfolio overview on the dashboard.
- Font is already a clean system-UI stack (San Francisco on Apple, system-ui elsewhere) — generic and professional, nothing stylized.

## Plus (from the prior slice, still here)
- 10-status deal system, color-coded, editable inline + filterable
- Full deal editing (funding details, status, balances, paydown)
- Live paydown tracker (payback, payment, payoff date, % paid in, remaining, renewal eligibility) with progress bar

## Database changes (all additive)
| Change | Type |
|---|---|
| `commission_payments` table | new |
| `commission_draws` table | new |
| `deals`: funded_amount, net_amount, factor_rate, term_mode, term_count, funding_date, amount_collected, renewal_notes | new columns |
| `deal_status` enum: +9 portfolio statuses | add-value |
| `funder_contacts.role` | new column |
| `funders.emails`, `funders.phones` | new columns |

No drops, no renames. `drizzle-kit push` adds only the above.

## Deploy
```bash
unzip -o mca-platform.zip && cp -rf mca-platform/. . && rm -rf mca-platform mca-platform.zip && rm -f .setup-complete
```
Then Stop → Run.

## CSV columns reference (funder import)
Required: `name`. Optional: `tiers`, `submission_method`, `submission_email`, `contact_name/phone/email`, `emails`, `phones`, `iso_rep`/`iso_rep_email`/`iso_rep_phone`, `underwriter`/`underwriter_email`/`underwriter_phone`, `funding_manager`/`funding_manager_email`/`funding_manager_phone`, `min_revenue`, `max_positions`, `min_credit_tier`, `restricted_states`, `restricted_industries`, `supports_reverse_consolidation`, `notes`, `additional_rules`. Multi-value columns accept pipe (`|`) or comma separation.

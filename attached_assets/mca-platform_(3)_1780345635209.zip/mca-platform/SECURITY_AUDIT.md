# Security Audit & Hardening — Summary

Performed across two deep-dive turns. This document records what was reviewed, what was fixed, and what was confirmed safe so you have a clean reference.

---

## Critical fixes (would block real attacks)

### 1. IDOR (Insecure Direct Object Reference) — 6 routes
**The bug:** A signed-in user from Company A could submit `PATCH/DELETE /api/<resource>/<UUID-from-Company-B>` and the write would succeed. The SELECT-then-UPDATE pattern verified ownership with a SELECT (filtered by companyId), but then the UPDATE/DELETE filtered by `id` only — meaning if an attacker guessed a UUID from another tenant, the write would land on that row.

**Affected routes:**
- `DELETE /api/submissions/[id]`
- `PATCH /api/accounting/[id]`
- `DELETE /api/accounting/[id]` (soft-delete)
- `PATCH /api/commissions/[id]`
- `PATCH /api/lead-source-commissions/[id]`
- `DELETE /api/lead-source-commissions/[id]` (soft-delete + cascade)
- `PATCH /api/lead-sources/[id]`
- `DELETE /api/lead-sources/[id]`

**Fix:** Every UPDATE/DELETE now uses `.where(and(eq(t.id, params.id), eq(t.companyId, ctx.companyId)))`. Defense in depth — even if a future code change drops the SELECT preflight, the write still can't touch another tenant.

### 2. Privilege escalation — company_admin could modify or delete master_admin
**The bug:** `/api/users/[id]` PATCH/PUT/DELETE had no role-based guard. A company_admin could promote themselves, demote you (master_admin), or delete your account.

**Fix:** Added `canActOn(callerRole, targetRole)`:
- master_admin can act on anyone
- company_admin can NOT touch master_admin
- rep / lead_source can't reach these endpoints at all

Also added runtime guard on `POST /api/users` so even bypassing the Zod enum, a company_admin can't create a master_admin.

### 3. Privilege escalation — `requireMasterAdmin` and `pageRequireMaster` were too permissive
**The bug:** Both accepted `master_admin` AND `company_admin`. Meant company admins could reach `/master` and `/api/master-funders/*`.

**Fix:** Both functions now strictly require `master_admin`. The "Companies" sidebar link is also conditionally rendered only for master_admin.

### 4. Self-lockout
**The bug:** An admin could demote themselves to rep or deactivate their own account, locking everyone out of admin functions in their company.

**Fix:** PUT and DELETE now refuse to:
- Demote your own admin role
- Deactivate your own account
- Leave the company with zero active admins (covers role demotion + deactivation + deletion of last admin)

---

## XSS / Injection fixes

### 5. SVG logo upload removed
SVG files can carry `<script>` tags. Currently rendered via `<img src=>` (safe), but if anyone ever switches to inline SVG, it becomes XSS. Logo upload now accepts PNG/JPG/WebP/GIF only.

### 6. CSS injection via tenant primary color
`branding.primaryColor` was interpolated raw into a `<style>` tag. An admin setting a malicious value like `red;}body{display:none` could break the page or smuggle other styles.

**Fix:** Whitelist sanitizer. Only HSL triples, hex, rgb/rgba, hsl/hsla, and bare color keywords pass. Anything else is dropped and the default token wins.

### 7. Email header injection
The `to:` and CC fields could contain CR/LF/NUL characters, which would let an attacker (or a malformed funder import) split the SMTP message and add unauthorized BCC/From/Subject headers — effectively forwarding every deal email to an attacker silently.

**Fix:** Both single-send and batch-send paths now reject:
- CR, LF, NUL bytes in any address
- Addresses that don't match the basic email regex
- Multiple addresses in a single recipient (existing rule, now hardened)

### 8. Attachment filename injection / path traversal
Uploaded filenames were sent straight to the recipient. Could contain `../../etc/passwd`, CR/LF (for header injection in Content-Disposition), NUL, or be 2000 chars long.

**Fix:** `sanitizeFilename()` strips CR/LF/NUL, replaces path separators with underscores, removes leading dots, caps at 200 chars, falls back to "attachment" if empty.

### 9. Open redirect on login
`/login?callbackUrl=https://evil.com` would push the user to evil.com after successful login — perfect for phishing.

**Fix:** `sanitizeCallbackUrl()` only allows same-site relative paths starting with a single `/`. Rejects `//evil.com`, `https://evil.com`, URL-encoded variants, and anything with CR/LF.

---

## DoS / resource exhaustion

### 10. No upload size cap on bulk funder import
A 500MB CSV would OOM the server during parse.

**Fix:** 10MB upload cap + 5000 row cap.

### 11. No size cap on email attachments
Same OOM risk.

**Fix:** 25MB per file + 50MB total + 30 file count. Returns HTTP 413 on overflow.

### 12. No rate limit on password reset
Token brute-force is impractical (huge hash space) but adds friction anyway.

**Fix:** 20 attempts / 10 minutes per IP.

---

## HTTP / network hardening

### 13. Added security headers
- `Cross-Origin-Opener-Policy: same-origin`
- `Cross-Origin-Resource-Policy: same-origin`
- `X-XSS-Protection: 1; mode=block` (legacy browsers)
- `Permissions-Policy: interest-cohort=()` (disable FLoC)

### 14. API cache hardening
- `Cache-Control: no-store, no-cache, must-revalidate` on all `/api/*`
- `Vary: Cookie, Authorization`

Prevents shared caches (CDNs, corporate proxies) from ever caching authenticated responses.

---

## What I verified safe (no change needed)

- Login is rate-limited (10 attempts / 5 min per email)
- Forgot-password is rate-limited (5 / 15 min per email) and doesn't leak email existence
- Encryption uses AES-256-GCM with random IVs + auth tags (proper, not ECB-mode amateur hour)
- `ENCRYPTION_KEY` length is validated at startup
- Error handler doesn't leak DB internals, stack traces, or env var names
- All admin settings APIs use `requireCompanyAdmin`
- Email body is sent as plain text — no HTML injection
- Tenant isolation on SELECT queries is consistent (every multi-tenant table filtered by `companyId`)
- Lead source portal correctly hides deal/merchant data from LS users
- SMTP and Sheets credentials are AES-256-GCM encrypted at rest
- SMTP GET endpoint never returns the encrypted password
- Sheets GET endpoint never returns encrypted credentials
- Email recipient validation rejects multi-recipient smuggling
- Master admin pages (`/master/*`) and APIs (`/api/master-*`) are strictly master-only
- NextAuth default cookie config is solid (httpOnly, secure in production, sameSite=lax)
- Health endpoint never leaks DB error details
- File uploads are processed in memory only — never written to disk

---

## Known accepted tradeoffs (not bugs)

1. **JWT staleness**: a demoted user keeps admin permissions in their JWT until they sign out or the 7-day max-age expires. This is a NextAuth/JWT default — to fix would require switching to database sessions or shortening max-age dramatically.
2. **Rate limiter is in-memory**: state resets when the server restarts and doesn't share across instances. Fine for single Replit deployment.
3. **`devCode` returned when system email is unconfigured**: bootstrapping convenience for password change flow. User must already be authenticated to hit the endpoint, so the risk is minimal.
4. **SMTP verify endpoint returns raw error message**: useful for debugging Gmail App Password issues. Admin-only endpoint, so leaking error details is acceptable.

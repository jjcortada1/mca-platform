'use client';

import { useEffect, useMemo, useState } from 'react';
import { Card, CardContent, PageHeader, Input, Button, CurrencyInput, PercentInput } from '@/components/ui/primitives';
import { ConfirmDialog } from '@/components/ui/confirm-dialog';
import { formatCurrency } from '@/lib/utils';
import { cn } from '@/lib/utils';
import { Search, Trash2, Plus } from 'lucide-react';
import { computePaydown } from '@/lib/deals/paydown';
import { formatCalendarDate, toDateInput } from '@/lib/dates';

interface Deal {
  id: string;
  name: string;
  merchantFirstName: string | null;
  merchantLastName: string | null;
  // Extended merchant + business fields — surfaced in the full-detail expand.
  // All optional / nullable so the type stays compatible with legacy rows.
  merchantPhone?: string | null;
  merchantEmail?: string | null;
  businessName?: string | null;
  businessAddress?: string | null;
  businessCity?: string | null;
  businessState?: string | null;
  businessZip?: string | null;
  industry?: string | null;
  status: string;
  fundedAmount: string | null;
  feePct: string | null;
  factorRate: string | null;
  termMode: string | null;
  termCount: string | null;
  fundingDate: string | null;
  amountCollected: string | null;
  assignedRepId: string | null;
  assignedRepName?: string | null;
  // Funded-deal sub-status. Null/missing → treated as 'active' in UI.
  fundedSubStatus?: 'active' | 'refi_eligible' | 'payment_issues' | 'default' | null;
  // Free-text fields displayed in the expand panel.
  notes?: string | null;
  renewalNotes?: string | null;
  // Audit timestamps — surfaced as "Created" / "Updated" in the detail grid.
  createdAt?: string | null;
  updatedAt?: string | null;
}

/** Sub-status labels + tones for the Funded Deals table. */
const FUNDED_SUB_STATUS: Record<string, { label: string; tone: string }> = {
  active:         { label: 'Active',          tone: 'emerald' },
  refi_eligible:  { label: 'Refi Eligible',   tone: 'teal' },
  payment_issues: { label: 'Payment Issues',  tone: 'amber' },
  default:        { label: 'Default',         tone: 'red' },
};

const TONE_CLASS: Record<string, string> = {
  amber: 'bg-amber-100 text-amber-800 border-amber-200', blue: 'bg-blue-100 text-blue-800 border-blue-200',
  gray: 'bg-gray-100 text-gray-700 border-gray-200', slate: 'bg-slate-100 text-slate-700 border-slate-200',
  violet: 'bg-violet-100 text-violet-800 border-violet-200', emerald: 'bg-emerald-100 text-emerald-800 border-emerald-200',
  rose: 'bg-rose-100 text-rose-800 border-rose-200', red: 'bg-red-100 text-red-800 border-red-200',
  orange: 'bg-orange-100 text-orange-800 border-orange-200', teal: 'bg-teal-100 text-teal-800 border-teal-200',
  cyan: 'bg-cyan-100 text-cyan-800 border-cyan-200',
};

type SortKey = 'recent' | 'pct_desc' | 'pct_asc' | 'balance_desc' | 'funded_desc';

export default function PortfolioPage() {
  const [deals, setDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [view, setView] = useState<'all' | 'paying' | 'refi'>('all');
  const [sort, setSort] = useState<SortKey>('recent');
  // Roster for the rep-assignment dropdown on each funded deal row.
  const [reps, setReps] = useState<{ id: string; name: string }[]>([]);
  // Delete confirmation state. When non-null, the ConfirmDialog renders and
  // the user can review the action before destruction. Reusable component
  // replaces native browser confirm() so the dialog doesn't appear in the
  // browser chrome at the top of the page.
  const [deleting, setDeleting] = useState<{ dealId: string; name: string } | null>(null);
  const [deleteLoading, setDeleteLoading] = useState(false);

  // Current user — used to enforce the "reps only see their own funded deals"
  // rule on the client side (the server enforces it independently). Admins
  // get a Rep filter dropdown that lets them slice the list by any rep.
  const [me, setMe] = useState<{ id: string; role: string } | null>(null);
  const isAdmin = me?.role === 'master_admin' || me?.role === 'company_admin';
  // Admin's rep filter: '' = all, 'mine' = current user, else specific repId.
  const [repFilter, setRepFilter] = useState<string>('');

  // "Add funded deal" drawer state. Lives in this top-level component so the
  // drawer survives table re-renders.
  const [showAdd, setShowAdd] = useState(false);

  useEffect(() => {
    // Load current user FIRST so we know whether to send `?mine=1`. We don't
    // actually need to wait — the server enforces the rep scoping by role —
    // but sending the param keeps the network trace explicit.
    fetch('/api/auth/me', { cache: 'no-store' }).then((r) => r.json()).then((j) => {
      if (j?.user) setMe({ id: j.user.id, role: j.user.role });
    }).catch(() => {});

    fetch('/api/deals', { cache: 'no-store' }).then((r) => r.json()).then((j) => {
      setDeals((j.data ?? j.deals ?? []) as Deal[]);
    }).catch(() => {}).finally(() => setLoading(false));

    // Load company users so the rep-assignment dropdown has the full roster.
    // Lead-source accounts excluded (they own deals via leadSourceId).
    fetch('/api/users', { cache: 'no-store' }).then((r) => r.json()).then((j) => {
      const list = (j.data ?? j.users ?? []) as { id: string; name: string | null; email: string; role: string }[];
      setReps(list
        .filter((u) => u.role !== 'lead_source')
        .map((u) => ({ id: u.id, name: u.name || u.email }))
        .sort((a, b) => a.name.localeCompare(b.name)));
    }).catch(() => {});
  }, []);

  async function performDelete() {
    if (!deleting) return;
    setDeleteLoading(true);
    const res = await fetch(`/api/deals/${deleting.dealId}`, { method: 'DELETE' });
    setDeleteLoading(false);
    if (res.ok) {
      // Optimistic remove from local state so the row disappears immediately.
      setDeals((arr) => arr.filter((d) => d.id !== deleting.dealId));
      setDeleting(null);
    } else {
      const j = await res.json().catch(() => ({}));
      alert(j.error || 'Could not delete this deal.');
    }
  }

  // Compute paydown for each FUNDED deal (live, as of today). We restrict
  // to status='funded' (and legacy aliases) so the Funded Deals page never
  // surfaces a deal that's still in the active pipeline.
  const FUNDED_STATUSES = new Set(['funded', 'paid_off', 'closed']);
  const enriched = useMemo(() => deals
    .filter((d) => FUNDED_STATUSES.has(d.status))
    .map((d) => ({
      deal: d,
      p: computePaydown({
        fundedAmount: d.fundedAmount, factorRate: d.factorRate, termMode: d.termMode,
        termCount: d.termCount, fundingDate: d.fundingDate, amountCollected: d.amountCollected,
      }),
    })), [deals]);

  const portfolio = useMemo(() => {
    // Include EVERY funded-status deal — both ones with a paydown structure
    // (full set: fundedAmount + factor + term + fundingDate) and ones that
    // still need funding details entered. The previous filter dropped the
    // un-populated cards entirely; per the new spec, funding details are
    // now entered HERE on Funded Deals (not Active Deals), so we have to
    // surface the cards that need attention.
    let list = enriched;

    // Rep filter:
    //   • Non-admin: hard-scoped to their own deals (defense in depth on top
    //     of the server-side filter — keeps any cached list private).
    //   • Admin with repFilter='mine': scope to admin's own deals.
    //   • Admin with repFilter=<repId>: scope to that rep.
    //   • Admin with empty repFilter: all funded deals.
    if (me && !isAdmin) {
      list = list.filter((e) => e.deal.assignedRepId === me.id);
    } else if (isAdmin && me && repFilter === 'mine') {
      list = list.filter((e) => e.deal.assignedRepId === me.id);
    } else if (isAdmin && repFilter && repFilter !== 'mine') {
      list = list.filter((e) => e.deal.assignedRepId === repFilter);
    }

    if (view === 'paying') list = list.filter((e) => e.p.hasStructure && !e.p.renewalEligible && e.p.pctPaidIn < 100);
    if (view === 'refi') list = list.filter((e) => e.p.hasStructure && e.p.renewalEligible);
    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter((e) =>
        e.deal.name.toLowerCase().includes(q) ||
        `${e.deal.merchantFirstName ?? ''} ${e.deal.merchantLastName ?? ''}`.toLowerCase().includes(q));
    }
    const sorted = [...list];
    switch (sort) {
      case 'pct_desc': sorted.sort((a, b) => b.p.pctPaidIn - a.p.pctPaidIn); break;
      case 'pct_asc': sorted.sort((a, b) => a.p.pctPaidIn - b.p.pctPaidIn); break;
      case 'balance_desc': sorted.sort((a, b) => b.p.remainingBalance - a.p.remainingBalance); break;
      case 'funded_desc': sorted.sort((a, b) => b.p.fundedAmount - a.p.fundedAmount); break;
      default: sorted.sort((a, b) => (new Date(b.deal.fundingDate ?? 0).getTime()) - (new Date(a.deal.fundingDate ?? 0).getTime()));
    }
    // Push deals without structure to the bottom of any non-pct sort so the
    // populated ones still lead the page.
    sorted.sort((a, b) => Number(b.p.hasStructure) - Number(a.p.hasStructure));
    return sorted;
  }, [enriched, view, search, sort, me, isAdmin, repFilter]);

  // Portfolio totals
  const totals = useMemo(() => {
    let funded = 0, payback = 0, collected = 0, remaining = 0, refi = 0;
    for (const e of enriched) {
      if (!e.p.hasStructure) continue;
      funded += e.p.fundedAmount; payback += e.p.totalPayback;
      collected += e.p.amountCollected; remaining += e.p.remainingBalance;
      if (e.p.renewalEligible) refi++;
    }
    return { funded, payback, collected, remaining, refi, count: enriched.filter((e) => e.p.hasStructure).length };
  }, [enriched]);

  return (
    <div className="space-y-5">
      <PageHeader
        title="Funded Deals"
        description="Live view of every funded deal — balance, paydown, and renewal status update automatically."
        actions={
          <Button size="sm" onClick={() => setShowAdd(true)} className="gap-1">
            <Plus className="h-4 w-4" />
            Add funded deal
          </Button>
        }
      />

      {/* Portfolio totals */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
        <Stat label="Active deals" value={String(totals.count)} />
        <Stat label="Funded volume" value={formatCurrency(totals.funded, { compact: true })} />
        <Stat label="Collected" value={formatCurrency(totals.collected, { compact: true })} tone="emerald" />
        <Stat label="Outstanding" value={formatCurrency(totals.remaining, { compact: true })} tone="amber" />
        <Stat label="Refi ready" value={String(totals.refi)} tone="teal" />
      </div>

      {/* Controls */}
      <div className="flex flex-wrap items-center gap-2">
        {([['all', 'All'], ['paying', 'Paying down'], ['refi', 'Refi ready']] as const).map(([k, label]) => (
          <button key={k} onClick={() => setView(k)}
            className={cn('px-3 py-1.5 rounded-full border text-xs font-medium transition',
              view === k ? 'bg-primary text-primary-foreground border-primary' : 'bg-card border-border text-muted-foreground hover:text-foreground')}>
            {label}
          </button>
        ))}
        <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)}
          className="h-8 rounded-full border border-input bg-card px-3 text-xs text-muted-foreground">
          <option value="recent">Newest funded</option>
          <option value="pct_desc">Most paid down</option>
          <option value="pct_asc">Least paid down</option>
          <option value="balance_desc">Highest balance</option>
          <option value="funded_desc">Largest funded</option>
        </select>
        {/* Rep filter — admin-only. Reps see only their own deals (forced
            both server-side and client-side) so the dropdown is hidden. */}
        {isAdmin && (
          <select
            value={repFilter}
            onChange={(e) => setRepFilter(e.target.value)}
            className="h-8 rounded-full border border-input bg-card px-3 text-xs text-muted-foreground max-w-[180px]"
            title="Filter funded deals by rep"
          >
            <option value="">All reps</option>
            <option value="mine">My deals only</option>
            <option disabled>──────────</option>
            {reps.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
          </select>
        )}
        <div className="ml-auto relative w-full sm:w-auto sm:min-w-[220px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search deals or merchants…" className="pl-9" />
        </div>
      </div>

      {loading ? (
        <div className="text-sm text-muted-foreground">Loading…</div>
      ) : portfolio.length === 0 ? (
        <Card><CardContent className="py-12 text-center text-sm text-muted-foreground">
          No funded deals yet. When a deal in Active Deals is marked &quot;Funded,&quot; it appears here.
        </CardContent></Card>
      ) : (
        <Card className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-muted/40 border-b border-border">
                <th className="w-8 px-2 py-2"></th>
                <th className="text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2">Deal</th>
                <th className="text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2">Status</th>
                <th className="text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2 hidden md:table-cell">Funded</th>
                <th className="text-right text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2">Funded $</th>
                <th className="text-right text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2 hidden lg:table-cell">Payback $</th>
                <th className="text-right text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2 hidden lg:table-cell">Term</th>
                <th className="text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2 w-40">% Paid</th>
                <th className="text-right text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2">Balance</th>
                <th className="text-left text-[10px] font-semibold uppercase tracking-wider text-muted-foreground px-3 py-2 hidden xl:table-cell">Renewal</th>
                <th className="w-10 px-2 py-2"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/60">
              {portfolio.map(({ deal, p }) => (
                <FundedDealRow
                  key={deal.id}
                  deal={deal}
                  p={p}
                  reps={reps}
                  onUpdated={(patched) => {
                    setDeals((arr) => arr.map((d) => d.id === deal.id ? { ...d, ...patched } : d));
                  }}
                  onRequestDelete={() => setDeleting({ dealId: deal.id, name: deal.name })}
                />
              ))}
            </tbody>
          </table>
        </Card>
      )}

      {/* Centered confirmation modal — replaces native browser confirm() so
          destructive flows live in-page instead of a top-of-browser popup. */}
      <ConfirmDialog
        open={!!deleting}
        title={`Delete "${deleting?.name ?? ''}"?`}
        description="This permanently removes the funded deal and all of its submissions, commissions, and history. The action cannot be undone."
        confirmLabel="Delete deal"
        destructive
        loading={deleteLoading}
        onConfirm={performDelete}
        onCancel={() => !deleteLoading && setDeleting(null)}
      />

      {/* Add-funded-deal drawer — creates a new deal with status='funded'
          and pre-filled funding details so it shows up here immediately. */}
      {showAdd && (
        <AddFundedDealDrawer
          reps={reps}
          onClose={() => setShowAdd(false)}
          onCreated={(d) => {
            setDeals((arr) => [d, ...arr]);
            setShowAdd(false);
          }}
        />
      )}
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: 'emerald' | 'amber' | 'teal' }) {
  const color = tone === 'emerald' ? 'text-emerald-700' : tone === 'amber' ? 'text-amber-700' : tone === 'teal' ? 'text-teal-700' : 'text-foreground';
  return (
    <Card><CardContent className="p-4">
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">{label}</div>
      <div className={cn('text-xl font-semibold tabular-nums mt-1', color)}>{value}</div>
    </CardContent></Card>
  );
}

/**
 * Funded-deal card. Two modes:
 *
 *   • Tracker mode  — when the deal has full paydown structure (funded amount,
 *     factor, term, fundingDate). Shows the live paydown tracker with progress
 *     bar, balance, refi eligibility, etc. Edit button toggles into editor mode.
 *
 *   • Editor mode   — for cards without complete paydown info AND when the
 *     user clicks Edit. Inputs for: funded amount, fee %, factor, term type +
 *     count, funding date, amount collected. Save persists via PATCH /api/deals/:id.
 *
 * Funding-detail entry only lives here on Funded Deals — Active Deals no
 * longer has these fields per the spec.
 */
/**
 * Funded-deal table row + expand panel.
 *
 * Layout follows the syndication-style dense table the user supplied:
 * collapsed row shows the high-signal columns (deal, status, funded date,
 * funded $, payback $, term, % paid with progress bar, balance, renewal
 * badge). Click the row to expand for full details + editor.
 *
 * Two expand-panel modes:
 *
 *   • Detail mode  — when the deal has full paydown structure (funded
 *     amount, factor, term, fundingDate). Shows the live paydown breakdown
 *     (payments, payoff date, daily/weekly payment amount, refi eligibility)
 *     plus an Edit button to switch to editor mode.
 *
 *   • Editor mode  — for cards without complete paydown info, OR when the
 *     user clicks Edit. Inputs for: funded amount, fee %, factor, term mode
 *     + count, funding date, amount collected. Save persists via PATCH
 *     /api/deals/:id.
 *
 * Funding-detail entry only lives here on Funded Deals — Active Deals no
 * longer has these fields per the spec.
 */
function FundedDealRow({
  deal,
  p,
  reps,
  onUpdated,
  onRequestDelete,
}: {
  deal: Deal;
  p: ReturnType<typeof computePaydown>;
  reps: { id: string; name: string }[];
  onUpdated: (patch: Partial<Deal>) => void;
  onRequestDelete: () => void;
}) {
  // Funded sub-status drives the badge instead of the broad deal.status when
  // we're on the Funded Deals page (every row here is funded by definition,
  // so showing "Funded" doesn't add information). Falls back to 'active' for
  // legacy rows that have no sub-status set yet.
  const subStatusKey = deal.fundedSubStatus ?? 'active';
  const subMeta = FUNDED_SUB_STATUS[subStatusKey] ?? FUNDED_SUB_STATUS.active;
  const merchant = `${deal.merchantFirstName ?? ''} ${deal.merchantLastName ?? ''}`.trim();

  // Auto-expand cards that don't have a paydown structure yet so the user
  // immediately sees the editor prompt and can fill in the funding details
  // (otherwise the row looks normal but offers nothing useful).
  const [expanded, setExpanded] = useState(!p.hasStructure);
  const [editing, setEditing] = useState(!p.hasStructure);
  const [saving, setSaving] = useState(false);
  const [draft, setDraft] = useState({
    fundedAmount: deal.fundedAmount ?? '',
    feePct: deal.feePct ?? '',
    factorRate: deal.factorRate ?? '',
    termMode: deal.termMode ?? 'weekly',
    termCount: deal.termCount ?? '',
    fundingDate: deal.fundingDate ? String(deal.fundingDate).slice(0, 10) : '',
    amountCollected: deal.amountCollected ?? '',
    // Sub-status + rep editable from the same form as funding details so
    // the user can change everything in one save round-trip.
    fundedSubStatus: subStatusKey as 'active' | 'refi_eligible' | 'payment_issues' | 'default',
    assignedRepId: deal.assignedRepId ?? '',
  });

  // Inline sub-status changer — small select on the table row that PATCHes
  // immediately so the user doesn't need to expand the row to update it.
  async function quickSetSubStatus(next: 'active' | 'refi_eligible' | 'payment_issues' | 'default') {
    // Optimistic local update for instant feedback.
    onUpdated({ fundedSubStatus: next });
    const res = await fetch(`/api/deals/${deal.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ fundedSubStatus: next }),
    });
    if (!res.ok) {
      // Roll back: re-fetch by reloading on the page-level state would be
      // overkill — we just leave the optimistic value; the user can retry.
    }
  }

  async function quickSetRep(repId: string) {
    const newRepName = repId ? (reps.find((r) => r.id === repId)?.name ?? null) : null;
    onUpdated({ assignedRepId: repId || null, assignedRepName: newRepName });
    await fetch(`/api/deals/${deal.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ assignedRepId: repId || null }),
    });
  }

  async function save() {
    setSaving(true);
    const body: Record<string, unknown> = { ...draft };
    for (const k of ['fundedAmount', 'feePct', 'factorRate', 'termCount', 'amountCollected'] as const) {
      if (body[k] === '') body[k] = null;
    }
    if (body.fundingDate === '') body.fundingDate = null;
    // Empty rep id → unassign (null) so the column clears.
    if (body.assignedRepId === '') body.assignedRepId = null;
    const res = await fetch(`/api/deals/${deal.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    setSaving(false);
    if (res.ok) {
      // Include the rep NAME in the optimistic patch so the row shows
      // the new rep without a full reload.
      const repName = body.assignedRepId
        ? (reps.find((r) => r.id === body.assignedRepId)?.name ?? null)
        : null;
      onUpdated({ ...(body as Partial<Deal>), assignedRepName: repName });
      setEditing(false);
    }
  }

  // % Paid bar color — green when refi eligible, blue otherwise, gray if
  // no structure (shows as empty bar so the column doesn't look broken).
  const pctColor = !p.hasStructure ? 'bg-muted-foreground/20'
    : p.renewalEligible ? 'bg-teal-500'
    : 'bg-primary';

  // Display values — fall back to em-dash for missing/unstructured cells so
  // the table doesn't render literal "NaN" or "$0" for a deal that hasn't
  // had its funding details entered yet.
  const fundedDisplay = p.hasStructure ? formatCurrency(p.fundedAmount, { compact: true }) : '—';
  const paybackDisplay = p.hasStructure ? formatCurrency(p.totalPayback, { compact: true }) : '—';
  const balanceDisplay = p.hasStructure ? formatCurrency(p.remainingBalance, { compact: true }) : '—';
  const termDisplay = p.hasStructure
    ? `${p.termCount} ${p.termMode === 'daily' ? 'd' : 'w'}`
    : '—';
  const fundedDateDisplay = p.fundingDate
    ? p.fundingDate.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: '2-digit' })
    : '—';
  const pctText = p.hasStructure ? `${p.pctPaidIn.toFixed(1)}%` : '—';

  return (
    <>
      <tr
        className={cn('transition-colors cursor-pointer',
          expanded ? 'bg-muted/40' : 'hover:bg-muted/30',
          !p.hasStructure && 'bg-amber-50/40'
        )}
        onClick={() => setExpanded(!expanded)}
      >
        <td className="px-2 py-2 text-muted-foreground text-center text-xs">
          {expanded ? '▾' : '▸'}
        </td>
        <td className="px-3 py-2 min-w-[180px]">
          <div className="font-medium truncate">{deal.name}</div>
          {merchant && <div className="text-[11px] text-muted-foreground truncate">{merchant}</div>}
        </td>
        <td className="px-3 py-2" onClick={(e) => e.stopPropagation()}>
          {/* Inline sub-status select. Tone color matches the picked status.
              Stops row-expand on click so the user can change status without
              the row jumping open. Patches immediately via quickSetSubStatus. */}
          <select
            value={subStatusKey}
            onChange={(e) => quickSetSubStatus(e.target.value as 'active' | 'refi_eligible' | 'payment_issues' | 'default')}
            className={cn(
              'rounded-full border px-2 py-0.5 text-[10px] font-medium cursor-pointer whitespace-nowrap',
              TONE_CLASS[subMeta.tone] ?? TONE_CLASS.gray
            )}
            title="Funded deal status"
          >
            <option value="active">Active</option>
            <option value="refi_eligible">Refi Eligible</option>
            <option value="payment_issues">Payment Issues</option>
            <option value="default">Default</option>
          </select>
        </td>
        <td className="px-3 py-2 text-xs text-muted-foreground tabular-nums whitespace-nowrap hidden md:table-cell">
          {fundedDateDisplay}
        </td>
        <td className="px-3 py-2 text-right tabular-nums font-medium whitespace-nowrap">{fundedDisplay}</td>
        <td className="px-3 py-2 text-right tabular-nums text-muted-foreground whitespace-nowrap hidden lg:table-cell">{paybackDisplay}</td>
        <td className="px-3 py-2 text-right tabular-nums text-muted-foreground text-xs whitespace-nowrap hidden lg:table-cell">{termDisplay}</td>
        <td className="px-3 py-2">
          <div className="flex items-center gap-2">
            <div className="flex-1 h-1.5 bg-muted rounded-full overflow-hidden min-w-[60px]">
              <div className={cn('h-full rounded-full transition-all', pctColor)} style={{ width: `${Math.min(100, p.pctPaidIn)}%` }} />
            </div>
            <span className={cn('text-xs tabular-nums font-medium w-12 text-right', p.renewalEligible && 'text-teal-700')}>{pctText}</span>
          </div>
        </td>
        <td className="px-3 py-2 text-right tabular-nums font-semibold whitespace-nowrap">{balanceDisplay}</td>
        <td className="px-3 py-2 hidden xl:table-cell">
          {p.renewalEligible
            ? <span className="inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium bg-teal-100 text-teal-800 border border-teal-200">Refi ready</span>
            : p.renewalDate
              ? <span className="text-[11px] text-muted-foreground tabular-nums">{p.renewalDate.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</span>
              : <span className="text-[11px] text-muted-foreground">—</span>}
        </td>
        {/* Actions cell — delete button. Click handler stops propagation so
            the row doesn't expand at the same time. Uses a confirmation
            modal (managed in the parent component) so the deletion isn't
            instant or browser-popup-based. */}
        <td className="px-2 py-2 text-right" onClick={(e) => e.stopPropagation()}>
          <button
            onClick={onRequestDelete}
            title="Delete this deal"
            className="text-muted-foreground hover:text-destructive transition-colors p-1 rounded hover:bg-destructive/10"
          >
            <Trash2 className="h-3.5 w-3.5" />
          </button>
        </td>
      </tr>

      {expanded && (
        <tr className="bg-muted/20">
          <td colSpan={11} className="px-4 py-4">
            <div className="space-y-3">
              {!editing && p.hasStructure && (
                <>
                  {/* Full detail panel — everything we know about this funded
                      deal. Grouped into sections so admins/reps can scan
                      quickly: paydown numbers → schedule → merchant info →
                      business info → notes/audit. Dates use
                      formatCalendarDate so they never shift one day from
                      the value that was typed in.
                      Fee % comes from the underlying deal record (not from
                      computePaydown) because the paydown engine doesn't
                      surface it. */}
                  <SectionLabel>Paydown</SectionLabel>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <Detail label="Funded amount" value={formatCurrency(p.fundedAmount)} />
                    <Detail label="Fee %" value={deal.feePct ? `${parseFloat(deal.feePct).toFixed(2)}%` : '—'} />
                    <Detail label="Factor rate" value={p.factorRate.toFixed(3)} />
                    <Detail label="Total payback" value={formatCurrency(p.totalPayback)} />
                    <Detail label="Amount collected" value={formatCurrency(p.amountCollected)} />
                    <Detail label="Remaining balance" value={formatCurrency(p.remainingBalance)} />
                    <Detail
                      label={p.termMode === 'daily' ? 'Daily payment' : 'Weekly payment'}
                      value={formatCurrency(p.paymentAmount)}
                    />
                    <Detail
                      label="Term"
                      value={`${p.termCount} ${p.termMode === 'daily' ? 'business days' : 'weeks'}`}
                    />
                    <Detail
                      label="Payments made"
                      value={`${p.paymentsMade} / ${p.paymentsTotal}`}
                    />
                    <Detail
                      label="% Paid in"
                      value={`${p.pctPaidIn.toFixed(2)}%`}
                      tone={p.renewalEligible ? 'teal' : undefined}
                    />
                    <Detail
                      label="Renewal eligibility"
                      value={p.renewalEligible
                        ? 'Eligible now'
                        : p.renewalDate
                          ? `~${formatCalendarDate(p.renewalDate)}`
                          : '—'}
                      tone={p.renewalEligible ? 'teal' : undefined}
                    />
                  </div>

                  <SectionLabel>Schedule</SectionLabel>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                    <Detail label="Funded date" value={formatCalendarDate(deal.fundingDate)} />
                    {/* First payment date: daily = next business day after
                        funding; weekly = same day, 7 days later. Matches the
                        cadence used by the buildPaymentSchedule generator. */}
                    <Detail
                      label="First payment"
                      value={p.fundingDate
                        ? formatCalendarDate(firstPaymentDate(p.fundingDate, p.termMode))
                        : '—'}
                    />
                    <Detail label="Est. payoff" value={p.payoffDate ? formatCalendarDate(p.payoffDate) : '—'} />
                    <Detail label="Term mode" value={p.termMode === 'daily' ? 'Daily (M–F)' : p.termMode === 'weekly' ? 'Weekly' : '—'} />
                  </div>

                  {/* Merchant + business contact info — pulled directly from
                      the deal record; nothing computed. */}
                  {(deal.merchantFirstName || deal.merchantLastName || deal.merchantEmail || deal.merchantPhone || deal.businessName) && (
                    <>
                      <SectionLabel>Merchant &amp; business</SectionLabel>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
                        <Detail label="Merchant" value={`${deal.merchantFirstName ?? ''} ${deal.merchantLastName ?? ''}`.trim() || '—'} />
                        <Detail label="Phone" value={deal.merchantPhone || '—'} />
                        <Detail label="Email" value={deal.merchantEmail || '—'} />
                        <Detail label="Business name" value={deal.businessName || '—'} />
                        {(deal.businessAddress || deal.businessCity || deal.businessState || deal.businessZip) && (
                          <Detail
                            label="Business address"
                            value={[deal.businessAddress, deal.businessCity, deal.businessState, deal.businessZip].filter(Boolean).join(', ') || '—'}
                          />
                        )}
                        {deal.industry && <Detail label="Industry" value={deal.industry} />}
                      </div>
                    </>
                  )}

                  {(deal.notes || deal.renewalNotes) && (
                    <>
                      <SectionLabel>Notes</SectionLabel>
                      <div className="space-y-2 text-xs">
                        {deal.notes && (
                          <div>
                            <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-0.5">Deal notes</div>
                            <div className="whitespace-pre-wrap text-foreground">{deal.notes}</div>
                          </div>
                        )}
                        {deal.renewalNotes && (
                          <div>
                            <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold mb-0.5">Renewal notes</div>
                            <div className="whitespace-pre-wrap text-foreground">{deal.renewalNotes}</div>
                          </div>
                        )}
                      </div>
                    </>
                  )}

                  {(deal.createdAt || deal.updatedAt) && (
                    <>
                      <SectionLabel>Audit</SectionLabel>
                      <div className="grid grid-cols-2 gap-3 text-xs">
                        {deal.createdAt && <Detail label="Created" value={formatCalendarDate(deal.createdAt)} />}
                        {deal.updatedAt && <Detail label="Updated" value={formatCalendarDate(deal.updatedAt)} />}
                      </div>
                    </>
                  )}

                  <div className="flex items-center justify-between gap-3 pt-2 border-t border-border">
                    {/* Quick rep changer in the detail view — same as the
                        editor but without entering edit mode. */}
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Assigned rep</span>
                      <select
                        value={deal.assignedRepId ?? ''}
                        onChange={(e) => quickSetRep(e.target.value)}
                        className="h-7 text-xs rounded-md border border-input bg-card px-2"
                      >
                        <option value="">Unassigned</option>
                        {reps.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                      </select>
                    </div>
                    <button onClick={() => setEditing(true)} className="text-xs font-medium text-primary hover:underline">
                      Edit funding details
                    </button>
                  </div>
                </>
              )}

              {!editing && !p.hasStructure && (
                <div className="text-xs text-amber-800 bg-amber-50 border border-amber-200 rounded-md px-3 py-2">
                  Funding details not entered yet. <button onClick={() => setEditing(true)} className="font-semibold underline">Add them</button> to enable paydown tracking.
                </div>
              )}

              {editing && (
                <div className="space-y-2">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">Funding details</div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                    <Field label="Funded amount">
                      <CurrencyInput value={String(draft.fundedAmount ?? '')} onChange={(v) => setDraft({ ...draft, fundedAmount: v })} placeholder="50,000" />
                    </Field>
                    <Field label="Fee">
                      <PercentInput value={String(draft.feePct ?? '')} onChange={(v) => setDraft({ ...draft, feePct: v })} placeholder="5" />
                    </Field>
                    <Field label="Factor rate">
                      <Input inputMode="decimal" value={String(draft.factorRate ?? '')} onChange={(e) => setDraft({ ...draft, factorRate: e.target.value })} placeholder="1.40" />
                    </Field>
                    <Field label="Term type">
                      <select value={draft.termMode ?? 'weekly'} onChange={(e) => setDraft({ ...draft, termMode: e.target.value })} className="h-9 w-full rounded-md border border-input bg-card px-2 text-sm">
                        <option value="weekly">Weekly</option>
                        <option value="daily">Daily</option>
                      </select>
                    </Field>
                    <Field label="# of payments">
                      <Input inputMode="numeric" value={String(draft.termCount ?? '')} onChange={(e) => setDraft({ ...draft, termCount: e.target.value })} placeholder="26" />
                    </Field>
                    <Field label="Funding date">
                      <Input type="date" value={toDateInput(draft.fundingDate ?? '')} onChange={(e) => setDraft({ ...draft, fundingDate: e.target.value })} />
                    </Field>
                    <Field label="Amount collected">
                      <CurrencyInput value={String(draft.amountCollected ?? '')} onChange={(v) => setDraft({ ...draft, amountCollected: v })} placeholder="auto if blank" />
                    </Field>
                    <Field label="Assigned rep">
                      <select
                        value={draft.assignedRepId}
                        onChange={(e) => setDraft({ ...draft, assignedRepId: e.target.value })}
                        className="h-9 w-full rounded-md border border-input bg-card px-2 text-sm"
                      >
                        <option value="">Unassigned</option>
                        {reps.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
                      </select>
                    </Field>
                    <Field label="Status">
                      <select
                        value={draft.fundedSubStatus}
                        onChange={(e) => setDraft({ ...draft, fundedSubStatus: e.target.value as 'active' | 'refi_eligible' | 'payment_issues' | 'default' })}
                        className="h-9 w-full rounded-md border border-input bg-card px-2 text-sm"
                      >
                        <option value="active">Active</option>
                        <option value="refi_eligible">Refi Eligible</option>
                        <option value="payment_issues">Payment Issues</option>
                        <option value="default">Default</option>
                      </select>
                    </Field>
                  </div>
                  <div className="flex justify-end gap-2 pt-1">
                    {p.hasStructure && (
                      <button onClick={() => setEditing(false)} className="text-xs text-muted-foreground hover:text-foreground">Cancel</button>
                    )}
                    <button
                      onClick={save}
                      disabled={saving}
                      className="h-8 px-3 rounded-md bg-foreground text-background text-xs font-medium hover:opacity-90 disabled:opacity-50"
                    >
                      {saving ? 'Saving…' : 'Save'}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </td>
        </tr>
      )}
    </>
  );
}

/** Small label/value pair used in the funded-deal expand detail grid. */
function Detail({ label, value, tone }: { label: string; value: string; tone?: 'teal' }) {
  return (
    <div>
      <div className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">{label}</div>
      <div className={cn('tabular-nums font-medium mt-0.5 break-words', tone === 'teal' ? 'text-teal-700' : 'text-foreground')}>{value}</div>
    </div>
  );
}

/** Section header inside the expand panel — groups Detail items into
 *  scannable buckets. */
function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[10px] font-semibold uppercase tracking-wider text-foreground/70 pt-2 first:pt-0">
      {children}
    </div>
  );
}

/**
 * Compute the first payment date from a funding date + term mode.
 *
 *   • daily   → next business day (Mon–Fri, skip Sat/Sun)
 *   • weekly  → same day of the week, 7 days later
 *
 * Mirrors the cadence used by buildPaymentSchedule so the displayed
 * "First payment" date is exactly when payment #1 lands.
 */
function firstPaymentDate(funded: Date, termMode: 'daily' | 'weekly' | null): Date | null {
  if (!termMode) return null;
  const d = new Date(funded);
  if (termMode === 'daily') {
    do { d.setDate(d.getDate() + 1); } while (d.getDay() === 0 || d.getDay() === 6);
  } else {
    d.setDate(d.getDate() + 7);
  }
  return d;
}

function Field({ label, children, required, className }: {
  label: string;
  children: React.ReactNode;
  required?: boolean;
  className?: string;
}) {
  return (
    <div className={cn('space-y-0.5', className)}>
      {label && (
        <div className="text-[9px] font-semibold uppercase tracking-wider text-muted-foreground">
          {label}
          {required && <span className="text-rose-600 ml-0.5">*</span>}
        </div>
      )}
      {children}
    </div>
  );
}

/**
 * Drawer to manually create a funded deal from the Funded Deals page.
 *
 * Why this exists: the normal deal lifecycle is shop → submit → active →
 * funded. But sometimes deals enter the system as funded already (back-fill,
 * direct paper, etc.) and the user shouldn't have to walk one through every
 * earlier status just to get it onto the tracker.
 *
 * Posts to /api/deals with status='funded' and all the funding-detail
 * fields populated. The new row is handed back to the parent so it appears
 * in the table immediately.
 */
function AddFundedDealDrawer({
  reps,
  onClose,
  onCreated,
}: {
  reps: { id: string; name: string }[];
  onClose: () => void;
  onCreated: (deal: Deal) => void;
}) {
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: '',
    merchantFirstName: '',
    merchantLastName: '',
    merchantPhone: '',
    merchantEmail: '',
    businessName: '',
    fundedAmount: '',
    feePct: '',
    factorRate: '',
    termMode: 'weekly' as 'weekly' | 'daily',
    termCount: '',
    fundingDate: '',
    amountCollected: '',
    assignedRepId: '',
    fundedSubStatus: 'active' as 'active' | 'refi_eligible' | 'payment_issues' | 'default',
    notes: '',
  });

  async function submit() {
    setErr(null);
    if (!form.name.trim()) { setErr('Deal name is required.'); return; }
    setSaving(true);
    // Build the request body, converting empty strings to null where the API
    // expects null (numeric / FK columns).
    const body: Record<string, unknown> = {
      name: form.name.trim(),
      status: 'funded',  // KEY — what makes this row appear on Funded Deals
      merchantFirstName: form.merchantFirstName.trim() || null,
      merchantLastName: form.merchantLastName.trim() || null,
      merchantPhone: form.merchantPhone.trim() || null,
      merchantEmail: form.merchantEmail.trim() || null,
      businessName: form.businessName.trim() || null,
      fundedAmount: form.fundedAmount || null,
      feePct: form.feePct || null,
      factorRate: form.factorRate || null,
      termMode: form.termMode,
      termCount: form.termCount || null,
      fundingDate: form.fundingDate || null,
      amountCollected: form.amountCollected || null,
      assignedRepId: form.assignedRepId || null,
      fundedSubStatus: form.fundedSubStatus,
      notes: form.notes.trim() || null,
    };
    const res = await fetch('/api/deals', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    setSaving(false);
    if (!res.ok) {
      const j = await res.json().catch(() => ({}));
      setErr(j.error || 'Could not create deal.');
      return;
    }
    const j = await res.json();
    const created = (j.data ?? j.deal) as Deal | undefined;
    if (created) onCreated(created);
    else onClose();
  }

  return (
    <div className="fixed inset-0 bg-black/40 z-40 flex justify-end" onClick={onClose}>
      <div
        className="w-full max-w-xl bg-background border-l border-border h-full overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-background border-b border-border px-6 py-4 flex items-center justify-between z-10">
          <h2 className="text-lg font-semibold">Add funded deal</h2>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={onClose} disabled={saving}>Cancel</Button>
            <Button size="sm" onClick={submit} disabled={saving}>{saving ? 'Saving…' : 'Create'}</Button>
          </div>
        </div>
        <div className="p-6 space-y-4">
          {err && <div className="text-xs text-rose-700 bg-rose-50 border border-rose-200 rounded px-3 py-2">{err}</div>}

          <SectionLabel>Deal</SectionLabel>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Deal name" required className="col-span-2">
              <Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Acme Pizza – 1st Position" />
            </Field>
            <Field label="Assigned rep">
              <select
                value={form.assignedRepId}
                onChange={(e) => setForm({ ...form, assignedRepId: e.target.value })}
                className="h-9 w-full rounded-md border border-input bg-card px-2 text-sm"
              >
                <option value="">Unassigned</option>
                {reps.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
              </select>
            </Field>
            <Field label="Status">
              <select
                value={form.fundedSubStatus}
                onChange={(e) => setForm({ ...form, fundedSubStatus: e.target.value as typeof form.fundedSubStatus })}
                className="h-9 w-full rounded-md border border-input bg-card px-2 text-sm"
              >
                <option value="active">Active</option>
                <option value="refi_eligible">Refi Eligible</option>
                <option value="payment_issues">Payment Issues</option>
                <option value="default">Default</option>
              </select>
            </Field>
          </div>

          <SectionLabel>Merchant</SectionLabel>
          <div className="grid grid-cols-2 gap-3">
            <Field label="First name">
              <Input value={form.merchantFirstName} onChange={(e) => setForm({ ...form, merchantFirstName: e.target.value })} />
            </Field>
            <Field label="Last name">
              <Input value={form.merchantLastName} onChange={(e) => setForm({ ...form, merchantLastName: e.target.value })} />
            </Field>
            <Field label="Business name" className="col-span-2">
              <Input value={form.businessName} onChange={(e) => setForm({ ...form, businessName: e.target.value })} />
            </Field>
            <Field label="Phone">
              <Input value={form.merchantPhone} onChange={(e) => setForm({ ...form, merchantPhone: e.target.value })} />
            </Field>
            <Field label="Email">
              <Input type="email" value={form.merchantEmail} onChange={(e) => setForm({ ...form, merchantEmail: e.target.value })} />
            </Field>
          </div>

          <SectionLabel>Funding</SectionLabel>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Funded amount">
              <CurrencyInput value={form.fundedAmount} onChange={(v) => setForm({ ...form, fundedAmount: v })} placeholder="50,000" />
            </Field>
            <Field label="Fee">
              <PercentInput value={form.feePct} onChange={(v) => setForm({ ...form, feePct: v })} placeholder="5" />
            </Field>
            <Field label="Factor rate">
              <Input inputMode="decimal" value={form.factorRate} onChange={(e) => setForm({ ...form, factorRate: e.target.value })} placeholder="1.40" />
            </Field>
            <Field label="Funding date">
              <Input type="date" value={form.fundingDate} onChange={(e) => setForm({ ...form, fundingDate: e.target.value })} />
            </Field>
            <Field label="Term type">
              <select
                value={form.termMode}
                onChange={(e) => setForm({ ...form, termMode: e.target.value as 'weekly' | 'daily' })}
                className="h-9 w-full rounded-md border border-input bg-card px-2 text-sm"
              >
                <option value="weekly">Weekly</option>
                <option value="daily">Daily</option>
              </select>
            </Field>
            <Field label="# of payments">
              <Input inputMode="numeric" value={form.termCount} onChange={(e) => setForm({ ...form, termCount: e.target.value })} placeholder="26" />
            </Field>
            <Field label="Amount collected" className="col-span-2">
              <CurrencyInput value={form.amountCollected} onChange={(v) => setForm({ ...form, amountCollected: v })} placeholder="auto if blank" />
            </Field>
          </div>

          <SectionLabel>Notes</SectionLabel>
          <Field label="">
            <textarea
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              rows={3}
              className="w-full rounded-md border border-input bg-card px-3 py-2 text-sm resize-y"
              placeholder="Optional context — funder name, special terms, etc."
            />
          </Field>
        </div>
      </div>
    </div>
  );
}
